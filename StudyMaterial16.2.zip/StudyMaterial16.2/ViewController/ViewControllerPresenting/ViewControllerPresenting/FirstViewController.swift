//
//  FirstViewController.swift
//  FirstViewControllerPresenting
//
//  Created by Nagarajan on 8/27/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    
    convenience init()
    {
        self.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    override func loadView()
    {
        super.loadView()
        
        let contentLabel = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 200))
        contentLabel.backgroundColor = UIColor.clear
        contentLabel.numberOfLines = 3
        contentLabel.text = "HAI, RIGHT NOW WE ARE IN FIRST VIEW CONTROLLER"
        contentLabel.font = UIFont.systemFont(ofSize: 20)
        contentLabel.center = self.view.center
        contentLabel.textColor = UIColor.white
        
        self.view.addSubview(contentLabel)
        self.view.backgroundColor = UIColor.lightGray
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.view.backgroundColor = UIColor.orange
        let singTap = UITapGestureRecognizer(target: self, action: #selector(FirstViewController.handleTapGesture(_:)))
        singTap.numberOfTapsRequired = 1
        singTap.numberOfTouchesRequired = 1
        self.view.addGestureRecognizer(singTap)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @objc func handleTapGesture(_ recognizer: UITapGestureRecognizer)
    {
        if(recognizer.state == UIGestureRecognizer.State.ended)
        {
            let secondController = SecondViewController()
            self.present(secondController, animated: true,
                completion: {
                    let alertView = UIAlertView(title: "View Controller Presenting",
                        message: "Second View Controller Presented",
                        delegate: nil,
                        cancelButtonTitle: "OK")
                    alertView.show()
            })
        }
    }

}

