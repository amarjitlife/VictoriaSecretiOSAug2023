____________________________________________________

Question 01: Write Following sum Function In C

	int sum( int x, int y )

____________________________________________________

Question 02: Write Following sum Function In C
	It Should Return Valid Arithmetic Sum
			OR
	Print Can't Calculate Sum For Given x And y

	int sum( int x, int y )

____________________________________________________
ATTEMPT 01: BAD CODE

	int sum( int x, int y ) {
		return x + y;
	}

____________________________________________________
ATTEMPT 02: WORKS BUT NOT BEST DESIGN
	Hardware Dependent Design

	int sum( int x, int y ) {
		int result = x + y;

		if ( ( x > 0 && y > 0 && result < 0 ) ||
		     ( x < 0 && y < 0 && result > 0 ) )
			printf("Can't Calculate Sum Of Given x And y Values");
		else {
			return x + y;

		}
	}

____________________________________________________

ATTEMPT 03: BAD CODE

	int sum( int x, int y ) {
		result = x + y;

		if MIN <= result <= MAX 
			return result 
		else
			Can't Calculate
	}

____________________________________________________

ATTEMPT 04: BAD CODE

	int sum( int x, int y ) {
		result = x + y;

		if MIN <= x, y, result <= MAX 
			return result 
		else
			Can't Calculate
	}

____________________________________________________

ATTEMPT 05: BAD CODE

	int sum( int x, int y ) {
		if MIN <= x, y <= MAX 
			result = x + y;
			return result 
		else
			Can't Calculate
	}

____________________________________________________

WHAT IS DATA TYPE?

1. SriPriya:
2. Sahana
3. Shivam
4. Vaibhav

____________________________________________________
____________________________________________________
____________________________________________________
____________________________________________________
____________________________________________________
____________________________________________________
____________________________________________________
