#include<stdio.h>

//_____________________________________________

int sum( int x, int y ) { 
	return x + y; 
}

int playWithSum() {
	int x = 2147483647; 
	int y = 2; 
	int result = 0;

	result = sum(x, y);
	printf("\nResult : %d", result);

	x = -2147483648; 
	y = -10; 

	result = sum(x, y);
	printf("\nResult : %d", result);
}

//_____________________________________________
// Valid Code In C/C++
// 	What About Java/Python???

void playWithIfElse() {
	int i = -10;
	// Can Use Any Expression Which Evaluates To int
	//		if Expression Value Is Zero 	-> It's False
	//		if Expression Value Is Non Zero -> It's True
	// if ( Expression ) {} else {}
	
	if ( i ) {
		printf("\nBalleeee Balleeee");
	} else {
		printf("Oyeee Hoyeee");
	}
}

//_____________________________________________

void playWithIfElseAgain() {
	int x = -10;
	int y = 0;

	// CODE 01
	if ( x ) {
		y = 20;
	} else {
		y = 100;
	}

	printf("\n y Value: %d", y );

	// CODE 02
	y = ( x ) ? 20 : 100;
	printf("\n y Value: %d", y );	
}


//_____________________________________________
//_____________________________________________
//_____________________________________________
//_____________________________________________

int main() {
	printf("\n\nFunction : playWithIfElse");
	playWithIfElse();

	printf("\n\nFunction : playWithIfElseAgain");
	playWithIfElseAgain();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}

// Result : -2147483647
// Result : 2147483638

