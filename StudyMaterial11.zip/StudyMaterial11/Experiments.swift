// Compile Swift Code
//      swiftc Experiments.swift -o experiments
// Run Swift Code
//      ./experiments

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// CLOSURES CAPTURING VALUES
// CLOSURES ARE REFERENCE TYPE

print("\n\n Function Returning A Function ")

// fun makeIncrementor( amount: Int ) : () -> Int {
func makeIncrementor( amount: Int ) -> () -> Int {
    var runningTotal = 0 // Local Variable
    // Local Function : Function Defined Insdie Function
	// fun incrementor() : Int {	
    func incrementor() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return incrementor
    // Local Variable Will Not Exists After Exit Of Function
}

let incrementorByTen: () -> Int = makeIncrementor( amount: 10 )
print( incrementorByTen() )
print( incrementorByTen() )
print( incrementorByTen() )

let incrementorBySeven: () -> Int = makeIncrementor( amount: 7 )
print( incrementorBySeven() )
print( incrementorBySeven() )

// Reference Assignment 
//		i.e. Both Are Pointing To The Same Objects
let incrementorByTenAgain = incrementorByTen
print( incrementorByTenAgain() )
print( incrementorByTenAgain() )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// In Swift Types Are Two Caterogires : Value Type and Reference Types
//      Value Types
//           Int, Char, String, FLoat, Double , Array

//      Reference Types
//          Closures

var some: [Int] = [10, 20, 30, 30, 40, 50]
var someAgain = some

print( some )
print( someAgain )

some[0] = 111

print( some )
print( someAgain )

func doChangeArray( data: [Int] ) {
    var data = data
    for (index, _) in data.enumerated() {
        data[ index ] = 999
    }
}

print("\n doChangeArray: Pass By Value Or Reference Check")
print( some )
doChangeArray( data: some )
print( some )

// Array Check: Pass By Value Or Reference
// [111, 20, 30, 30, 40, 50]
// [111, 20, 30, 30, 40, 50]

func doChangeArrayAgain( data: inout [Int] ) {
    // var data = data
    for (index, _) in data.enumerated() {
        data[ index ] = 999
    }
}

print("\n doChangeArrayAgain: Pass By Value Or Reference Check")
print( some )
doChangeArrayAgain( data: &some )
print( some )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!
