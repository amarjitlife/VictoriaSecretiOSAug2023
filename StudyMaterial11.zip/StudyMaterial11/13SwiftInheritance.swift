// Compile Swift Code
//      swiftc 13SwiftInheritance.swift -o inhteritance
// Run Swift Code
//      /inhteritance 

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Creating Vehicle Type
//      Operations = { init, description }
//      Range = { (x, y) : x, y Type Of Int }
class Vehicle {
    var numberOfWheels: Int
    var maxPassengers: Int

    init() {
        print("Initialser Called...")
        numberOfWheels = 0
        maxPassengers   = 1
    }

    func description() -> String {
        return "Wheels : \(numberOfWheels) Passengers: \(maxPassengers) "
    }
}

let someVehicle = Vehicle()

// Creating Bicycle Type
//      Operations = { init, description }
//      Range = { (x, y) : x, y Type Of Int }
class Bicycle: Vehicle {
    override init() {
        super.init() 
        numberOfWheels = 2
    }
}

let bicycle = Bicycle()
print("Bicycle : \(bicycle.description())")

// Creating Tandem Type
//      Operations = { init, description }
//      Range = { (x, y) : x, y Type Of Int }
class Tandem: Bicycle {
    override init() {
        super.init() 
        maxPassengers = 2
    }
}

let tandem = Tandem()
print("Tandem : \( tandem.description() )")


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// In Java
// h Is Reference To Human Type Object
//      Generally References Store In Stack
///     and Java Objects Are Stored In Heap
// Human h = new Human( 420, "Gabbar Singh");
// Above Statement Is Equivalent To Following C Code

// Object Allocation/Creation
// Human *h = (Human *) malloc( sizeof( Human ) );

// Constructor Does Initialisation
// h.id = 420;
// h.name = "Gabbar Singh";

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

class Car: Vehicle {
    var speed: Double = 0.0
    
    override init() {
        super.init()

        maxPassengers = 5
        numberOfWheels = 4
    }

    // override init() 
    // {
    //     super.init()
    //     maxPassengers = 5
    //     numberOfWheels = 4
    // }

    override func description() -> String {
        return super.description() + "; " + "traveling at \(speed) mph"
    }
}
let car = Car()
print("Car: \(car.description())")

class SpeedLimitedCar: Car {
    override var speed: Double {
        get { return super.speed                }
        set { super.speed = min(newValue, 40.0) }
    }
}
let limitedCar = SpeedLimitedCar()
limitedCar.speed = 60.0
print("SpeedLimitedCar: \(limitedCar.description())")

class AutomaticCar: Car {
    var gear = 1

    override var speed: Double {
        didSet { 
            gear = Int(speed / 10.0) + 1
        }
    }

    override func description() -> String {
        return super.description() + " in gear \(gear)"
    }
}
let automatic = AutomaticCar()
automatic.speed = 35.0
print("AutomaticCar: \(automatic.description())")


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________

// https://codebunk.com/b/6011100615319/
// https://codebunk.com/b/6011100615319/
// https://codebunk.com/b/6011100615319/

//__________________________________________________________
