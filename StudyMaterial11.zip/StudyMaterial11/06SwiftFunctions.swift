// Compile Swift Code
// 		swiftc 06SwiftFunctions.swift -o functions
// Run Swift Code
//		./functions

//____________________________________________________________________
// Function 
//		Taking String Type Argument
//		Return String Type Value

func greet( person: String ) -> String {
	let greeting = "Hello, " + person + "!"
	return greeting
}

func greetAgain( person: String ) -> String {
	return "Hello, " + person + "!"
}

print( greet( person: "Basanti") )
print( greet( person: "Gabbar Singh") )
print( greetAgain( person: "Basanti") )
print( greetAgain( person: "Gabbar Singh") )

//____________________________________________________________________
// Function  
//		Taking No Argument
//		Return String Type Value

func sayHelloWorld() -> String {
	return "Hello World!"
}

print( sayHelloWorld() )

// Function  
//		Taking Taking One Argument of String Type
//		Returning No VAlue

func greetOnce(person: String ) {
	print("Hello \(person)!")
}

greetOnce( person: "Gabbar Singh")

//____________________________________________________________________

func greetOnceAgain( person: String, alreadyGreeted: Bool ) -> String {
	if alreadyGreeted {
		return greetAgain( person: person )
	} else {
		return greet( person: person )
	}
}

print( greetOnceAgain( person: "Gabbar Singh", alreadyGreeted: false ) )
print( greetOnceAgain( person: "Gabbar Singh", alreadyGreeted: true ) )

//____________________________________________________________________
// Function  
//		Taking Taking One Argument of String Type
//		Returning Value Of Int Type

func printAndCount(string: String) -> Int {
    print(string)
    return string.count
}

// Function  
//		Taking Taking One Argument of String Type
//		Returning No Value

func printWithoutCounting(string: String) {
    let _ = printAndCount(string: string)
}

let result = printAndCount(string: "hello, world")
print( result )
// prints "hello, world" and returns a value of 12
printWithoutCounting(string: "hello, world")
// prints "hello, world" but doesn't return a value

//____________________________________________________________________

// Function
//		Takes One Argument Of Type [Int]
//		Returns Tuple Value Of Type (Int, Int)

func minMax( array: [Int] ) -> (min: Int, max: Int) {
	var currentMin = array[0]
	var currentMax = array[0]

	for value in array[1..<array.count] {
		if value < currentMin {
			currentMin = value
		} else if value > currentMax {
			currentMax = value
		}
	}

	return ( currentMin, currentMax )
}

let bounds = minMax( array: [10, 20, -10, -90, 9999, 88, 67] )
print( "Minimum Is : \(bounds.min) and Max is \(bounds.max)" )


//____________________________________________________________________

func minMaxAgain( array: [Int] ) -> (min: Int, max: Int)? {
	if array.isEmpty { return nil }

	var currentMin = array[0]
	var currentMax = array[0]

	for value in array[1..<array.count] {
		if value < currentMin {
			currentMin = value
		} else if value > currentMax {
			currentMax = value
		}
	}

	return ( currentMin, currentMax )
}


let boundsAgain: (Int, Int)? = minMaxAgain( array: [10, 20, -10, -90, 9999, 88, 67] )
// print( "Mimimum and Maximum : \(boundsAgain)" )
if let bounds: (Int, Int) = boundsAgain {
	print( "Mimimum and Maximum : \(bounds)" )
	print( "Mimimum and Maximum : \(bounds.0)  \(bounds.1)" )
}


//____________________________________________________________________
// Functions With an Implicit Return

// If the entire body of the function is a single expression, 
// The function implicitly returns that expression.
func greeting(for person: String) -> String {
    "Hello, " + person + "!"
}
print(greeting(for: "Dave"))
// Prints "Hello, Dave!"

func anotherGreeting(for person: String) -> String {
    return "Hello, " + person + "!"
}
print(anotherGreeting(for: "Dave"))

//____________________________________________________________________

// Function Argument Labels and Parameter Names
// Each function parameter has both an argument label and a parameter name. 

func someFunction(firstParameterName: Int, secondParameterName: Int) -> String {
    // In the function body, firstParameterName and secondParameterName
    // refer to the argument values for the first and second parameters.
	"Some Function With Values: \(firstParameterName) \(secondParameterName)"
}

print( someFunction(firstParameterName: 1, secondParameterName: 2) )

func someFunctionAgain( _ firstParameterName: Int, secondParameterName: Int) -> String {
    // In the function body, firstParameterName and secondParameterName
    // refer to the argument values for the first and second parameters.
	"Some Function With Values: \(firstParameterName) \(secondParameterName)"
}

print( someFunctionAgain( 1, secondParameterName: 2) )

//____________________________________________________________________
// Function Parameter Names
// External Parameter Names

// Elephants Teeths
//		For Showing
//		For Eathing
func someFunction(argumentLabel parameterName: Int) {
    // In the function body, parameterName refers to 
    // the argument value for that parameter.
}

func greetOnceMore( person: String, from hometown: String) -> String {
	return "Hello \(person) Belongs To \(hometown)"
}

var value = greetOnceMore( person: "Gabbar Singh", from: "Ramgarh")
print( value )


func someFunction(externalParameterName localParameterName: Int) -> Int {
    return localParameterName
}

func join(s1: String, s2: String, joiner: String) -> String {
    return s1 + joiner + s2
}
value = join(s1: "hello", s2: "world", joiner: ", ") // Parameter meanings are not clear
print( value )

// Creating A Better API
func join(string s1: String, toString s2: String, withJoiner joiner: String) -> String {
    // return s1 + joiner + s2
    return join(s1: "hello", s2: "world", joiner: ", ")
}

value = join(string: "Hello", toString: "World", withJoiner: ", ")
print( value )

//____________________________________________________________________
// Variadic Function
//		Function Taking Variable Number Of Parameters
//		i.e. Functions Having Variadic Arguments/Parameters

func arithmeticMean( numbers: Double... ) -> Double {
	var total : Double = 0
	for number in numbers {
		total += number
	}

	return total / Double( numbers.count )
}

print( arithmeticMean())
print( arithmeticMean( numbers: 10 ))
print( arithmeticMean( numbers: 10, 20, 30, 40, 50 ))
print( arithmeticMean( numbers: 10, 20, 30, 40, 50, 60, 99, 80 ))

//____________________________________________________________________
// Default Parameter Values

func someFunctionMore(parameterWithoutDefault: Int, parameterWithDefault: Int = 12) {
    // If you omit the second argument when calling this function, then
    // the value of parameterWithDefault is 12 inside the function body.
}
someFunctionMore(parameterWithoutDefault: 3, parameterWithDefault: 6) // parameterWithDefault is 6
someFunctionMore(parameterWithoutDefault: 4)

//____________________________________________________________________

// func swap( a: Int, b: Int ) {
// 	let temp = a
// 	a = b 
// 	b = temp
// }

// func swap( a: Int, b: Int ) {
// 	var aa = a
// 	var bb = b
// 	let temp = a
// 	aa = bb 
// 	bb = temp
// }

// Pass-By Reference In Swift
func swap( a: inout Int, b: inout Int ) {
	let temp = a
	a = b 
	b = temp
}

var aa = 100
var bb = 200

print(aa, bb)
// swap(a: aa, b: bb)
swap(a: &aa, b: &bb)

print(aa, bb)


//____________________________________________________________________

// Function Type Is (Int, Int) -> Int
func sum(a: Int, b: Int) -> Int { return a + b }
func sub(a: Int, b: Int) -> Int { return a - b }
func mul(a: Int, b: Int) -> Int { return a * b }

// Higher Order Function
//		Functions Which Takes Function As Arguments
//				AND/OR
//		Returns Functions

// Polymorphic Functions
//		Using Mechanism: By Passing Behaviour To Behaviour
//					i.e. By Passing Function TO Function
func calculator( a: Int, b: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation(a, b)
}

var outputResult: Int
let xx = 11
let yy = 22

outputResult = calculator( a: xx, b: yy, operation: sum )
print( outputResult )

outputResult = calculator( a: xx, b: yy, operation: sub )
print( outputResult )

outputResult = calculator( a: xx, b: yy, operation: mul )
print( outputResult )

// Closure Or Lambda Expressions
let sumLambda = { (x: Int, y: Int) -> Int in return x + y }
let subLambda = { (x: Int, y: Int) -> Int in return x - y }
let mulLambda = { (x: Int, y: Int) -> Int in return x * y }

outputResult = calculator( a: xx, b: yy, operation: sumLambda )
print( outputResult )

outputResult = calculator( a: xx, b: yy, operation: subLambda )
print( outputResult )

outputResult = calculator( a: xx, b: yy, operation: mulLambda )
print( outputResult )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

let something0 = sum
outputResult = something0( 99, 11 )
print( outputResult )

let something1: (Int, Int) -> Int  = sum
outputResult = something1( 99, 11 )
print( outputResult )

let somethingAgain = calculator
outputResult = somethingAgain( 99 , 88, sum)
print( outputResult )

let somethingOnceAgain: (Int, Int, (Int,Int) -> Int ) -> Int  = calculator
outputResult = somethingOnceAgain( 99, 88, sub )
print( outputResult )

//___________________________________________________________________

// Function Type For stepForward And stepBackward Is
//		(Int) -> Int
func stepForward( input : Int ) -> Int  { return input + 1 }
func stepBackward( input : Int ) -> Int { return input - 1 }

// Polymorphic Functions
//		Using Mechanism: By Passing Behaviour To Behaviour
//					i.e. By Passing Function TO Function

// Higher Order Function
//		Functions Which Takes Function As Arguments
//				AND/OR
//		Returns Functions
func chooseStepFunction( backward: Bool ) -> (Int) -> Int {
	return backward ? stepBackward : stepForward
}

var currentValue = 5
let moveTowardsZero = chooseStepFunction( backward: currentValue > 0 )

while currentValue != 0 {
	print("\(currentValue)")
	currentValue = moveTowardsZero( currentValue )
}

let somethingMore0 = stepForward
let somethingMore1: (Int) -> Int = stepForward

let somethingOnceMore0 = chooseStepFunction
let somethingOnceMore1: (Bool) -> (Int) -> Int  = chooseStepFunction

// Invoke Above somethings...

//____________________________________________________________________

// Polymorphic Functions
//		Using Mechanism: By Passing Behaviour To Behaviour
//					i.e. By Passing Function TO Function

// Higher Order Function
//		Functions Which Takes Function As Arguments
//				AND/OR
//		Returns Functions

// Nested Functions
//		Function Defined Inside Function

func chooseStepFunctionAgain( backward: Bool ) -> (Int) -> Int {
	func stepForward( input : Int ) -> Int  { return input + 1 }
	func stepBackward( input : Int ) -> Int { return input - 1 }

	return backward ? stepBackward : stepForward
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

