// Compile Swift Code
//      swiftc 11SwiftProperties.swift -o properties
// Run Swift Code
//      ./properties

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Properties
// 		Stored Properties

struct FixedLengthRange {
	// Instance Member Propertiess
    var firstValue: Int
    let length: Int
}

// error: cannot assign to property: 'rangeOfThreeItems' is a 'let' constant
// let rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)
var rangeOfThreeItems = FixedLengthRange(firstValue: 0, length: 3)

print( rangeOfThreeItems )

rangeOfThreeItems.firstValue = 6

print( rangeOfThreeItems )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

struct Point {
	// Instance Member Propertiess
    var x = 0.0, y = 0.0
}

struct Size {
	// Instance Member Propertiess
    var width = 0.0, height = 0.0
}

struct Rect {
	// Instance Member Propertiess
    var origin = Point() 	// Stored Property
    var size = Size() 	 	// Stored Property	
    var center: Point { 	// Computed Property
	    get {
	    	print("center Getter Called")
	        let centerX = origin.x + (size.width / 2)
	        let centerY = origin.y + (size.height / 2)
	        return Point(x: centerX, y: centerY)
	    }

	    set( newCenter ) {
	    	print("center Setter Called")
	        origin.x = newCenter.x - (size.width / 2)
	        origin.y = newCenter.y - (size.height / 2)
	    }
	}
}

var square = Rect(origin: Point(x: 0.0, y: 0.0), size: Size(width: 10.0, height: 10.0))
let initialSquareCenter = square.center  // Calling Getter
square.center = Point(x: 15.0, y: 15.0)  // Callsing Setter

print("square.origin is now at (\(square.origin.x), \(square.origin.y))")


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

struct RectAgain {
    var origin = Point()
    var size = Size()
    var center: Point {
	    get {
	        let centerX = origin.x + (size.width / 2)
	        let centerY = origin.y + (size.height / 2)
	        return Point(x: centerX, y: centerY)
	    }

	    set {
	        origin.x = newValue.x - (size.width / 2)
	        origin.y = newValue.y - (size.height / 2)
	    }
    }
}

var square1 = RectAgain(origin: Point(x: 0.0, y: 0.0), size: Size(width: 10.0, height: 10.0))
let initialSquareCenter1 = square1.center
square1.center = Point(x: 15.0, y: 15.0)
print("square.origin is now at (\(square1.origin.x), \(square1.origin.y))")

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

struct Cuboid {
    var width = 0.0, height = 0.0, depth = 0.0
    var volume: Double  {
	     get {
		    	return width * height * depth
	     }
	 }
}

struct CuboidAgain {
    var width = 0.0, height = 0.0, depth = 0.0
    var volume: Double { // Shortcut Getter Syntax
	     // get {
		    	return width * height * depth
	     // }
    }
}

let fourByFiveByTwo = Cuboid(width: 4.0, height: 5.0, depth: 2.0)
print("the volume of fourByFiveByTwo is \(fourByFiveByTwo.volume)")

print( fourByFiveByTwo.volume )

// error: cannot assign to property: 'volume' is a get-only property
// fourByFiveByTwo.volume = 100

print( fourByFiveByTwo.volume )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Type Members

struct SomeStructure {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 1
    }
}

enum SomeEnumeration {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 6
    }
}

class SomeClass {
    static var storedTypeProperty = "Some value."
    static var computedTypeProperty: Int {
        return 27
    }

    class var overrideableComputedTypeProperty: Int {
        return 107
    }
}

print(SomeStructure.storedTypeProperty)             // prints "Some value."
SomeStructure.storedTypeProperty = "Another value."
print(SomeStructure.storedTypeProperty)             // prints "Another value."
print(SomeEnumeration.computedTypeProperty)         // prints "6"
print(SomeClass.computedTypeProperty)               // prints "27"


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!


