// Compile Swift Code
//      swiftc 14SwiftInitialisation.swift -o initialisation
// Run Swift Code
//      ./initialisation 

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\n\nDefining Constructor")

struct Fahrenheit {
    var temperature: Double

    init() {
        temperature = 32.0
    }
}

var f = Fahrenheit()
print("The default temperature is \(f.temperature)° Fahrenheit")

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\n\nOverloading Constructors Based On Parameter Labels")

struct Celsius {
    var temperatureInCelsius: Double = 0.0

    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32) / 1.8
    }

    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }
}
let boilingPointOfWater  = Celsius(fromFahrenheit: 212.0)
let freezingPointOfWater = Celsius(fromKelvin: 273.15)

print( boilingPointOfWater )
print( freezingPointOfWater)


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Internal Parameters and External Parameters Names Are Same

print( "\n\nInternal Parameters and External Parameters Names Are Same")

struct Color {
    let red, green, blue: Double

    init(red: Double, green: Double, blue: Double) {
        self.red   = red
        self.green = green
        self.blue  = blue
    }

    init(white: Double) {
        red     = white
        green   = white
        blue    = white
    }
}

let magenta  =  Color(red: 1.0, green: 0.0, blue: 1.0)
let halfGray =  Color(white: 0.5)

print( magenta )
print( halfGray )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print( "\n\nInternal Parameters and External Parameters Names Are Different")

struct Celsius2 {
    var temperatureInCelsius: Double = 0.0

    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32) / 1.8
    }

    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }

	// Ignore External Parameter Name Generation
	//		Not Recommended Practice Because Code Readability Will Decrease
	//		Used Only In Rarest Rare Case
	//				e.g. Making API Compatible To C/C++/Java Language
    init(_ celsius: Double) {
        temperatureInCelsius = celsius
    }
}

let bodyTemperature1 = Celsius2(fromFahrenheit: 98.5)
let bodyTemperature2 = Celsius2(fromKelvin: 310.0)
let bodyTemperature3 = Celsius2( 37.0 ) // External Parameter Is Not Generated

print( bodyTemperature1 )
print( bodyTemperature2 )
print( bodyTemperature3 )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\nOptional Properties...")

class SurveyQuestion {
    var text: String
    var response: String?

    init(text: String) {
        self.text = text
    }

    func ask() { // Default Return Type Of Function ()
        print(text)
    }
}

let cheeseQuestion = SurveyQuestion(text: "Do you like cheese?")
cheeseQuestion.ask() 

print( cheeseQuestion.response ?? "Unknown")
cheeseQuestion.response = "Yes, I do like cheese."
print( cheeseQuestion.response ?? "Unknown")

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\nImmutable Properties")

class SurveyQuestion2 {
	// Immtutable Property
    let text: String
    var response: String?

    init(text: String) {
    	// Can Initialse Immutable Properties In Initialser
        self.text = text
    }

    func ask() {
        print(text)
    }

    func doChange( text: String ) {
		// error: cannot assign to property: 'text' is a 'let' constant
    	// self.text = text 
    }
}

let beetsQuestion = SurveyQuestion2(text: "How about beets?")
beetsQuestion.ask()

print( beetsQuestion.response ?? "Unknown")
beetsQuestion.response = "I also like beets. (But not with cheese.)"
print( beetsQuestion.response ?? "Unknown")

beetsQuestion.doChange( text: "Ella Elllllaa!" )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// DESGIN 01 : Properties Initialsed With Default Values
//			Initialiser Will Be Generated With Having Logic
//				To Set All Properties To Default Values
print( "\nDESGIN 01 : Properties With Default Values" )

class ShoppingListItemDesign1 {
	// var name: String? = nil
    var name: String? 	// Default Values For Nullables/Optional Types Is nil
    var quantity 		= 1
    var purchased 		= false

    var description : String {
    	get {
    		return "ShoppingListItem(name: \(name ?? "UNKNOWN"), quantity:\(quantity), purchased: \(purchased))"
    	}
    }

    // func description() -> String {
    // 		return "ShoppingListItem(name: \(name ?? "UNKNOWN"), quantity:\(quantity), purchased: \(purchased)"
    // }
}

let item1 = ShoppingListItemDesign1()
// print( item.description() )
print( item1.description )

// let item2 = ShoppingListItemDesign1(name: "Gabbar Singh", quantity: 1, purchased: false )
// print( item2.description )


// DESGIN 02 : Properties Initialsed With init()" )
print( "\nDESGIN 02 : Properties Initialsed With init()" )

//  error: class 'ShoppingListItemAgain' has no initializers
class ShoppingListItemDesign2 {
    var name: String? 			// Default Values For Nullables/Optional Types Is nil
    var quantity : Int	 		// = 1
    var purchased : Bool 		// = false

    init() {
    	self.name = nil 	// Explicitly Initilaising To nil To Make Intension Clear
    						// By Default Implicitly Nullables/Optional Types Will Be Initialised To nil
    	// error: return from initializer without initializing all stored properties
    	self.quantity  = 0
    	self.purchased = false
    }

    var description : String {
    	get {
    		return "ShoppingListItem(name: \(name ?? "UNKNOWN"), quantity:\(quantity), purchased: \(purchased))"
    	}
    }

    // func description() -> String {
    // 	return "ShoppingListItem(name: \(name ?? "UNKNOWN"), quantity:\(quantity), purchased: \(purchased)"
    // }
}

let itemAgain = ShoppingListItemDesign2()

// // print( item.description() )
print( itemAgain.description )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

struct Size1 {
	var width = 0.0, height = 0.0
}

//			    Generated Memberwise Initialser Which Initialse All The Member Properties
let twoByTwo1 = Size1( width: 2.0, height: 2.0 )
print( twoByTwo1 )

let twoByTwo2 = Size1() //  Size1( width: 0.0, height: 0.0 )
print( twoByTwo2 )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

struct Size {
    var width = 0.0, height = 0.0
}

struct Point {
    var x = 0.0, y = 0.0
}

struct Rect {
    var origin = Point()
    var size = Size()
    
    init() { 
    	print("Constructor With No Arguments Called...") 
    	print( "Origin and Size Before Constructor Intialisation")
    	print( origin ) 		
    	print( size )

		// 1. Default Values Get Initialised First 
		// 2. Than Constructor Logic Initialses Members
    	print( "Origin and Size After Constructor Intialisation")
    	origin 	= Point( x: 1.1, y: 1.1 )
    	size 	= Size( width: 11, height: 11 )
	}
    
    init(origin: Point, size: Size) {
        self.origin = origin
        self.size = size
    }

    init(center: Point, size: Size) {
        let originX = center.x - (size.width / 2)
        let originY = center.y - (size.height / 2)
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

let basicRect  = Rect() //
print( basicRect )

let originRect = Rect(origin: Point(x: 2.0, y: 2.0), size: Size(width: 5.0, height: 5.0))
print( originRect )

let centerRect = Rect(center: Point(x: 4.0, y: 4.0), size: Size(width: 3.0, height: 3.0))
print( centerRect )


//__________________________________________________________

// Swfit Automatic Initializers Rules

// Rule 1
//   If your subclass doesn't define any designated initializers, 
//      It automatically inherits all of its superclass designated initializers

// Rule 2
//   If your subclass provides an implementaction of all of its superclass 
//   designated initializers- 
        // Either by inheriting them as per rule 1, 
        // Or by providing a custom implementation as part of its definitition- 
        // It automatically inherits all of the superclass convenience initializers.
//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!


// Designated and Convenience Initializers in Action

print( "\nDesignated and Convenience Initializers in Action")

class Food {
    var name: String
    init(name: String) {
        self.name = name
    }

    convenience init() {
        self.init(name: "[Unnamed]")
    }
}
let namedMeat = Food(name: "Bacon")
let mysteryMeat = Food()

class RecipeIngredient: Food {
    var quantity: Int
    
    init(name: String, quantity: Int) {
        self.quantity = quantity
        super.init(name: name)
    }
    
    override convenience init(name: String) {
        self.init(name: name, quantity: 1)
    }
}

let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)

//  In this example, the superclass for RecipeIngredient is Food, 
        // which has a single convenience initializer called init(). 
        // This initializer is therefore inherited by RecipeIngredient. 
        // The inherited version of init() functions in exactly the 
        //  same way as the Food version, 
                // Except that it delegates to the RecipeIngredient version 
                //      of init(name: String) Rather than the Food version.

class ShoppingListItem2: RecipeIngredient {
    var purchased = false

    var description: String {
        var output = "\(quantity) x \(name)"
        output += purchased ? " √" : " ✘"
        return output
    }
}

var breakfastList = [
    ShoppingListItem2(),
    ShoppingListItem2(name: "Bacon"),
    ShoppingListItem2(name: "Eggs", quantity: 6),
]

breakfastList[0].name = "Orange juice"
breakfastList[0].purchased = true
for item in breakfastList {
    print(item.description)
}

//  Because ShoppingListItem2 provides a default value for all of the properties 
        // it introduces and does not define any initializers itself, 
        // ShoppingListItem automatically inherits all of the designated 
		//		and convenience initializers from its superclass. 
        // 		ShoppingListItem2(name: "Eggs, quantity: 6),


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Failable Initialser 

print( "\nFailable Initialser" ) 

struct Animal {
    let species: String

    init?(species: String) {
        if species.isEmpty { return nil }
        self.species = species
    }
}

let someCreature1 = Animal( species: "Giraffe" )
print( someCreature1 ?? "UNDEFINED" )

let someCreature2: Animal? = Animal( species: "Giraffe" )
print( someCreature2 ?? "UNDEFINED" )

let someCreature3 = Animal( species: "" )
print( someCreature3 ?? "UNDEFINED" )

if let giraffe = someCreature1 {
    print("An animal was initialized with a species of \(giraffe.species)")
}

let anonymousCreature = Animal(species: "")

if anonymousCreature == nil {
    print("The anonymous creature could not be initialized")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Failable Initializers for Enumerations

print("\n Failable Initializers for Enumerations ")
enum TemperatureUnit {
    case Kelvin, Celsius, Fahrenheit
    init?(symbol: Character) {
        switch symbol {
        case "K":
            self = .Kelvin
        case "C":
            self = .Celsius
        case "F":
            self = .Fahrenheit
        default:
            return nil
        }
    }
}

let fahrenheitUnit = TemperatureUnit(symbol: "F")
if fahrenheitUnit != nil {
    print("This is a defined temperature unit, so initialization succeeded.")
}

let unknownUnit = TemperatureUnit(symbol: "X")
if unknownUnit == nil {
    print("This is not a defined temperature unit, so initialization failed.")
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!
print("\n Failable Initializers for Enumerations with Raw Values")

// Failable Initializers for Enumerations with Raw Values


enum TempUnit: Character {
    case Kelvin = "K", Celsius = "C", Fahrenheit = "F"
}

let fahrUnit = TempUnit(rawValue:"F")
if fahrUnit != nil {
    print("This is a defined temperature unit, so initialization succeeded.")
}

let unknownUnit2 = TempUnit(rawValue: "X")
if unknownUnit2 == nil {
    print("This is not a defined temperature unit, so initialization failed.")
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!
print("\n Failable Initializers for Classes")

// Failable Initializers for Classes
// Failable initializers for value types can trigger failure at any point. 
// For classes, however a failable initializer can trigger an initialization failure 
        // Only after all stored properties introduced by that class have been set to an initial value.
class Product {
    let name: String!

    // Propogating Nothingness
    init?(name: String) {
        self.name = name
        if name.isEmpty { return nil }
    }
}

let bowTie: Product? = Product(name: "bow tie")
print( bowTie ?? "UNKNOWN" )

class ProductAgain {
    let name: String!

    // Not Propogating Nothingness
    init(name: String) {
        self.name = name
        // if name.isEmpty { return nil }
    }
}

let bowTieAgain: ProductAgain = ProductAgain(name: "bow tie")
print( bowTieAgain )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\nPropagation of Initialization Failure")

// Propagation of Initialization Failure

class CartItem: Product {
    let quantity: Int!

    init?(name: String, quantity: Int) {
        self.quantity = quantity

        super.init(name: name)
        if quantity < 1 { return nil }
    }
}

if let twoSocks = CartItem(name: "sock", quantity: 2) {
    print("Item: \(String(describing: twoSocks.name )), quantity: \( String(describing: twoSocks.quantity))")

}

// if let zeroShirts = CartItem(name: "shirt", quantity: 0) {
//     print("Item: \(zeroShirts.name), quantity: \(zeroShirts.quantity)")
// } else {
//     print("Unable to initialize zero shirts")
// }

// if let oneUnnamed = CartItem(name: "", quantity: 1) {
//     print("Item: \(oneUnnamed.name), quantity: \(oneUnnamed.quantity)")
// } else {
//     print("Unable to initialize one unnamed product")
// }


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!
print("\n // Overriding a Failable Initializer")

// Overriding a Failable Initializer


class Document {
    var name: String?
    // this initializer creates a document with a nil name value
    init() {}

    // this initializer creates a document with a non-empty name value
    init?(name: String) {
        self.name = name
        if name.isEmpty { return nil }
    }
}

class AutomaticallyNamedDocument: Document {
    override init() {
        super.init()
        self.name = "[Untitled]"
    }

    override init(name: String) {
        super.init()
        if name.isEmpty {
            self.name = "[Untitled]"
        } else {
            self.name = name
        }
    }
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!
print("\n // Setting a default Property Value with a Closure or Function")


class SomeClass {
    let someProperty: Int = { // Assigning Lambda/Closure
        // create a default value for someProperty inside this closure
        // someValue must be of the same type as SomeType
            return 1234
        }() // Invoking Lambda/Closure
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!
print("\n // Setting a default Property Value with a Closure or Function")

struct Checkerboard {

    let boardColors: [Bool] = { // Assinging Lambda/Closure
        var temporaryBoard = [Bool]()
        var isBlack = false
        for i in 1...10 {
            for j in 1...10 {
                temporaryBoard.append(isBlack)
                isBlack = !isBlack
            }
            isBlack = !isBlack
        }
        return temporaryBoard
    }() // Invoking Lambda/Closure
    
    func squareIsBlackAtRow(row: Int, column: Int) -> Bool {
        return boardColors[(row * 10) + column]
    }
}

let board = Checkerboard()
print( board )

print(board.squareIsBlackAtRow(row: 0, column: 1))
print(board.squareIsBlackAtRow(row: 9, column: 9))

print( board )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\n Deinitialers")

// Class definitions can have at most one deinitializer per class. 
// The deinitializer does not take any parameters and is written without parentheses:

struct Bank {
    static var coinsInBank = 10_000

    static func vendCoins(numberOfCoinsToVend: Int) -> Int {
        let numberOfCoinsToVend1 = min(numberOfCoinsToVend, coinsInBank)
        coinsInBank -= numberOfCoinsToVend1
        return numberOfCoinsToVend
    }

    static func receiveCoins(coins: Int) {
        coinsInBank += coins
    }
}

class Player {
    var coinsInPurse: Int
    
    init(coins: Int) {
        coinsInPurse = Bank.vendCoins(numberOfCoinsToVend: coins)
    }
    
    func winCoins(coins: Int) {
        coinsInPurse += Bank.vendCoins(numberOfCoinsToVend: coins)
    }
    
    deinit {
    	print("Deinitialers Called...")
        Bank.receiveCoins(coins: coinsInPurse)
    }
}

var playerOne: Player? = Player(coins: 100)
print("A new player has joined the game with \(playerOne!.coinsInPurse) coins")
print("There are now \(Bank.coinsInBank) coins left in the bank")

playerOne!.winCoins(coins: 2_000)
print("PlayerOne won 2000 coins & now has \(playerOne!.coinsInPurse) coins")
print("The bank now only has \(Bank.coinsInBank) coins left")

playerOne = nil
print("PlayerOne has left the game")
print("The bank now has \(Bank.coinsInBank) coins")
print( Bank.coinsInBank )


//__________________________________________________________

// https://codebunk.com/b/6011100615319/
// https://codebunk.com/b/6011100615319/
// https://codebunk.com/b/6011100615319/

//__________________________________________________________
