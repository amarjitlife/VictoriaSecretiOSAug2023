// Compile Swift Code
// 		swiftc 03SwiftStrings.swift -o strings
// Run Swift Code
//		./strings

//____________________________________________________________
//____________________________________________________________

let someString = "Some String Data"

print( someString )

let emptyString = ""
if emptyString.isEmpty {
	print("Empty String Found!")
} else {
	print("Non Empty String Found!")
}

let emptyStringAgain = String()
if emptyStringAgain.isEmpty {
	print("Empty String Found!")
} else {
	print("Non Empty String Found!")
}

let greeting1 = "Good Morning!"

// error: cannot assign to value: 'greeting' is a 'let' constant
// greeting = greeting + " Jawaaanooo!"
print( greeting1 )

var greetingAgain = "Good Morning!"
greetingAgain = greetingAgain + " Jawaaanooo!"
print( greetingAgain )

//____________________________________________________________
//____________________________________________________________

// Iterating On Unicode String
//		Picking Each Unicode Character
for character in "Dog!🐶" {
	print( character )
}

// Interred And Binded Type Will Be String
// let exclamationMark = "!"

let exclamationMark : Character  = "!"
let catCharacters: [ Character ] = [ "C", "a", "t", "!", "🐱" ]
let catString = String( catCharacters )
print( catString )

for character in catString {
	print( character )
}

let catAndDogString = catString + "Dog!🐶"
print( catAndDogString )

for character in catAndDogString {
	print( character )
}

let string1  = "Welcome"
let string2 = " Young Learners"
var welcome = string1 + string2
print( welcome )

welcome.append( exclamationMark )
print( welcome )

// error: cannot convert value of type 'Character' to expected argument type 'String'
// welcome = welcome + exclamationMark

welcome = welcome + String( exclamationMark )
print( welcome )

// String Inpterpolation
let mutliplier = 3
let message = "\(mutliplier) times 2.5 is \( Double( mutliplier) * 2.5 )"
print( message )

//____________________________________________________________
//____________________________________________________________

let wiseWords = "\"Imagintation is more important than knowledge - Einstein\""
print( wiseWords )

//				 Unicode Point
let dollarSign: Character = "\u{24}"
let blackHeart = "\u{2665}"
let sparklingHeart = "\u{1F496}" 
print( dollarSign )
print( blackHeart )
print( sparklingHeart)

// Unicode Character Can Be Represented 
//		With Different Unicode Points Combinations
let eAcute : Character = "\u{E9}"  			  // é 
let eAcuteAgain : Character = "\u{65}\u{301}" // e Followed By ́
print( eAcute )
print( eAcuteAgain )

let precomposed: Character = "\u{D55C}"                 // 한
let decomposed: Character = "\u{1112}\u{1161}\u{11AB}"  // ᄒ ᅡ  ᆫ
// There Is No Unicode Character Exists For Following Ordered Unicode Points
// let decomposedAgain: Character = "\u{11AB}\u{1112}\u{1161}"
let decomposedAgain: String = "\u{11AB}\u{1112}\u{1161}"

print( precomposed )
print( decomposed )
print( decomposedAgain )

let enclosedEAcute: Character = "\u{E9}\u{20DD}"
print( enclosedEAcute )

let regionalIndicatorForUS: Character = "\u{1F1FA}\u{1F1F8}"
print( regionalIndicatorForUS )

let regionalIndicatorForAUS: Character = "\u{1F1E6}\u{1F1FA}"
print( regionalIndicatorForAUS )

var word = "cafe"
print("Word \(word) Have Characters Numbers : \(word.count) ")

word += "\u{301}"
print("Word \(word) Have Characters Numbers : \(word.count) ")


let quotation = "We're a lot alike, you and I."
let sameQuotation = "We're a lot alike, you and I."

if quotation == sameQuotation {
    print("These two strings are considered equal")
} else {
	print("Not Equal")
}

// "Voulez-vous un café?" using LATIN SMALL LETTER E WITH ACUTE
let eAcuteQuestion = "Voulez-vous un caf\u{E9}?"
// "Voulez-vous un café?" using LATIN SMALL LETTER E and COMBINING ACUTE ACCENT
let combinedEAcuteQuestion1 = "Voulez-vous un caf\u{65}\u{301}?"
let combinedEAcuteQuestion2 = "Voulez-vous un cafe\u{301}?"

if eAcuteQuestion == combinedEAcuteQuestion1 {
    print("These two strings are considered equal")
} else {
	print("Not Equal")
}

if eAcuteQuestion == combinedEAcuteQuestion2 {
    print("These two strings are considered equal")
} else {
	print("Not Equal")
}

if combinedEAcuteQuestion1 == combinedEAcuteQuestion2 {
    print("These two strings are considered equal")
} else {
	print("Not Equal")
}

// Conversely, characters that are visually similar 
// but do not have the same linguistic meaning are 
// not considered equal.
let latinCapitalLeterA: Character = "\u{41}"
let cyrillicCapitalLetterA: Character = "\u{0410}"

print( latinCapitalLeterA )
print( cyrillicCapitalLetterA )
if latinCapitalLeterA != cyrillicCapitalLetterA {
    print("These two characters are not equivalent")
}

//____________________________________________________________

let badStart = """
    one
    two
    """
let end = """
    three
    """
print(badStart + end)
// Prints two lines:
// one
// twothree


let goodStart = """
    one
    two

    """
print(goodStart + end)
// Prints three lines:
// one
// two
// three

//____________________________________________________________
// String Functions

let greeting = "Guten Tag!"

var someCharacter = greeting[ greeting.startIndex ]
print( someCharacter )

// G
someCharacter = greeting[greeting.index(before: greeting.endIndex)]
print( someCharacter )

// !

someCharacter = greeting[greeting.index(after: greeting.startIndex)]
print( someCharacter )

// u

let index = greeting.index( greeting.startIndex, offsetBy: 7)
someCharacter = greeting[index]
print( someCharacter )

// a

// greeting[greeting.endIndex] // Error
// greeting.index(after: greeting.endIndex) // Error

for character in greeting {
	print( character )
}

for index in greeting.indices {
    print("AT \(index) : \(greeting[index]) \n", terminator: "")
}

var welcomeAgain = "hello"
print( welcomeAgain )
welcomeAgain.insert("!", at: welcomeAgain.endIndex)
// welcome now equals "hello!"
print( welcomeAgain )

welcomeAgain.insert(contentsOf: " there", at: welcomeAgain.index(before: welcomeAgain.endIndex) )
// welcome now equals "hello there!"
print( welcomeAgain )

welcomeAgain.remove(at: welcomeAgain.index(before: welcomeAgain.endIndex))
// welcome now equals "hello there"
print( welcomeAgain )

let range = welcomeAgain.index(welcomeAgain.endIndex, offsetBy: -6)..<welcomeAgain.endIndex
welcomeAgain.removeSubrange(range)
// welcome now equals "hello"
print( welcomeAgain )


let greeting2 = "Hello, world!"
let index1 = greeting2.firstIndex(of: ",")  ??  greeting2.endIndex
let beginning = greeting2[..<index1]
// beginning is "Hello"
print( beginning )

// Convert the result to a String for long-term storage.
let newString = String(beginning)
print( newString )

//____________________________________________________________

// Prefix and Suffix Equality
let romeoAndJuliet = [
    "Act 1 Scene 1: Verona, A public place",
    "Act 1 Scene 2: Capulet's mansion",
    "Act 1 Scene 3: A room in Capulet's mansion",
    "Act 1 Scene 4: A street outside Capulet's mansion",
    "Act 1 Scene 5: The Great Hall in Capulet's mansion",
    "Act 2 Scene 1: Outside Capulet's mansion",
    "Act 2 Scene 2: Capulet's orchard",
    "Act 2 Scene 3: Outside Friar Lawrence's cell",
    "Act 2 Scene 4: A street in Verona",
    "Act 2 Scene 5: Capulet's mansion",
    "Act 2 Scene 6: Friar Lawrence's cell"
]

var act1SceneCount = 0

for scene in romeoAndJuliet {
    if scene.hasPrefix("Act 1") {
        act1SceneCount += 1
    }
}
print("There are \(act1SceneCount) scenes in Act 1")

var mansionCount = 0
var cellCount = 0
for scene in romeoAndJuliet {
    if scene.hasSuffix("Capulet's mansion") {
        mansionCount += 1
    } else if scene.hasSuffix("Friar Lawrence's cell") {
        cellCount += 1
    }
}
print("\(mansionCount) mansion scenes; \(cellCount) cell scenes")

//____________________________________________________________

// Unicode Representations of Strings
let dogString = "Dog!🐶"

for character in dogString {
	print( character )
}

// UTF-8 Representation
for codeUnit in dogString.utf8 {
    print("\(codeUnit) ", terminator: "")
}
print("")

// UTF-16 Representation
for codeUnit in dogString.utf16 {
    print("\(codeUnit) ", terminator: "")
}
print("")

// Unicode Scalar Representation
for scalar in dogString.unicodeScalars {
    print("\(scalar.value) ", terminator: "")
}
print("")

for scalar in dogString.unicodeScalars {
    print("\(scalar)")
}

//____________________________________________________________
//____________________________________________________________

// https://codebunk.com/b/6011100615319/
// https://codebunk.com/b/6011100615319/
// https://codebunk.com/b/6011100615319/


