// Compile Swift Code
// 		swiftc SwiftIntroduction.swift -o introduction
// Run Swift Code
//		./introduction

print("Hello World!!!")

// error: cannot assign to value: 'hello' is a 'let' constant
// let Keyword Creates Immutables
// let hello = "Hello World!"

// var Keyword Creates Mutables

// Type Inferencing and Binding
// 1. Type Inferrencing Done From RHS
// 2. Type (Inferred) Binded With LHS

// Implicity Type Inferrencing and Binding Happens
var hello = "Hello World!"

// Type Annotation
// Explicit Type Inferrencing and Binding Happens
var helloAgain: String = "Hello World!"

print( hello )
print( helloAgain )

hello = "Hello Youth of India!!!"
print( hello )

let myConstant = 90
print( myConstant )

let implicitInteger = 70
let implicitDouble = 90.90
let explicitDouble: Double = 90.90
let explicitFloat : Float = 90

print( implicitInteger )
print( implicitDouble )
print( explicitDouble )
print( explicitFloat )

let apples = 3
let oranges  = 5

// String Interpolation 
//		Substituting Expression's Values
let appleSummary = "I have \(apples) apples"
let fruitsSummary = "I have \(apples + oranges) Fruits"

print( appleSummary )
print( fruitsSummary )

let pi = 3.14
let 𝝿 = 3.14
print( pi )
print( 𝝿 )

let namaste = "नमस्ते"
print( namaste )

let नमस = 1111
print( नमस )

var shoppingList = ["Shoes", "Watch", "Dress", "Bag" ]
var shoppingListAgain: [String] = ["Shoes", "Watch", "Dress", "Bag" ]

print( shoppingList )
print( shoppingListAgain )

print( shoppingList[0] )
print( shoppingList[1] )

let something = ""
let somethingAgain = String()

print("Empty String: \(something) ")
print("Empty String: \(somethingAgain) ")

let emptyArray: [String] = []
let emptyArrayAgain = [String]()

print( emptyArray )
print( emptyArrayAgain )

let label = "The width is: "
let width = 90

// error: binary operator '+' cannot be applied to operands of type 'String' and 'Int'
// let labelledWidth = label + width
let labelledWidth = label + String( width )
print( labelledWidth )

