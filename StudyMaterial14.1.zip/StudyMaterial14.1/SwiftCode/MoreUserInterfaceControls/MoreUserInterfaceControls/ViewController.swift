//
//  ViewController.swift
//  MoreUserInterfaceControls
//
//  Created by System Administrator on 7/27/15.
//  Copyright (c) 2015 TechHueSystems. All rights reserved.
//

import UIKit
// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func < <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l < r
  case (nil, _?):
    return true
  default:
    return false
  }
}

// FIXME: comparison operators with optionals were removed from the Swift Standard Libary.
// Consider refactoring the code to use the non-optional operators.
fileprivate func > <T : Comparable>(lhs: T?, rhs: T?) -> Bool {
  switch (lhs, rhs) {
  case let (l?, r?):
    return l > r
  default:
    return rhs < lhs
  }
}


class ViewController: UIViewController, UIActionSheetDelegate
{
    var controlView: THSUIView?
    var nameField: THSUITextField?
    var numberField: THSUITextField?
    var imageView: THSUIImageView?
    var name: THSUILabel?
    var number: THSUILabel?
    var sliderLabel: THSUILabel?
    var slider: THSUISlider?
    var segmented: THSUISegmentedControl?
    var leftSwitch, rightSwitch: THSUISwitch?
    var doSomethingButton: THSUIButton?
    
    convenience init()
    {
        self.init(nibName: nil, bundle: nil)
    }

    required init?(coder aDecoder: NSCoder)
    {
        fatalError("init(coder:) has not been implemented")
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?)
    {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.view?.backgroundColor = UIColor(red: 0.4, green: 0.2, blue: 0.6, alpha: 0.9)
    }

    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func loadView()
    {
        super.loadView()
        controlView = THSUIView(frame: CGRect(origin: self.view!.bounds.origin,
            size: self.view!.bounds.size))
        controlView!.addTarget(self, action: #selector(ViewController.backgroundTap(_:)), for: UIControl.Event.touchDown)
        self.view!.addSubview(controlView!)
        
        let image:UIImage = UIImage(named: "Apple.png")!
        imageView = THSUIImageView(frame: CGRect(x: 110, y: 30, width: 100, height: 100))
        imageView?.image = image
        controlView?.addSubview(imageView!)
        
        nameField = THSUITextField(frame: CGRect(x: 120, y: 130, width: 170, height: 30))
        nameField?.borderStyle = UITextField.BorderStyle.roundedRect
        nameField?.font = UIFont.systemFont(ofSize: 17)
        nameField?.keyboardType = UIKeyboardType.default
        nameField?.addTarget(self, action: #selector(ViewController.textFieldDoneEditing(_:)), for: UIControl.Event.editingDidEndOnExit)
        controlView?.addSubview(nameField!)
        
        name = THSUILabel(frame: CGRect(x: 30, y: 130, width: 80, height: 30))
        name?.text = "Name"
        name?.textAlignment = NSTextAlignment.left
        name?.font = UIFont.systemFont(ofSize: 15)
        name?.textColor = UIColor.black
        controlView?.addSubview(name!)
        
        number = THSUILabel(frame: CGRect(x: 30, y: 170, width: 80, height: 30))
        number?.text = "Number"
        number?.textAlignment = NSTextAlignment.left
        number?.font = UIFont.systemFont(ofSize: 15)
        number?.textColor = UIColor.black
        controlView?.addSubview(number!)
        
        sliderLabel = THSUILabel(frame: CGRect(x: 30, y: 210, width: 40, height: 20))
        sliderLabel?.text = "0"
        sliderLabel?.textAlignment = NSTextAlignment.left
        sliderLabel?.font = UIFont.systemFont(ofSize: 15)
        sliderLabel?.textColor = UIColor.black
        controlView?.addSubview(sliderLabel!)
        
        slider = THSUISlider(frame: CGRect(x: 80, y: 210, width: 210, height: 20))
        slider?.minimumValue = 0
        slider?.maximumValue = 100
        slider?.addTarget(self, action: #selector(ViewController.sliderChanged(_:)), for: UIControl.Event.valueChanged)
        controlView?.addSubview(slider!)
        
        let item = ["Switches", "Button"]
        segmented = THSUISegmentedControl(items: item as [AnyObject]?)
        segmented?.frame = CGRect(x: 30, y: 240, width: 250, height: 60)
        segmented?.selectedSegmentIndex = 0;
        segmented?.addTarget(self, action: #selector(ViewController.toggleControls(_:)), for: UIControl.Event.valueChanged)
        controlView?.addSubview(segmented!)
        
        leftSwitch = THSUISwitch(frame: CGRect(x: 30, y: 320, width: 50, height: 25))
        leftSwitch?.setOn(true, animated: true)
        
        leftSwitch?.addTarget(self, action: #selector(ViewController.switchChanged(_:)), for: UIControl.Event.valueChanged)
        controlView?.addSubview(leftSwitch!)
        
        rightSwitch = THSUISwitch(frame: CGRect(x: 220, y: 320, width: 50, height: 25))
        rightSwitch?.setOn(true , animated: true)
        rightSwitch?.addTarget(self, action: #selector(ViewController.switchChanged(_:)), for: UIControl.Event.valueChanged)
        controlView?.addSubview(rightSwitch!)
        
        doSomethingButton = THSUIButton(frame: CGRect(x: 30, y: 320, width: 260, height: 30))
        doSomethingButton?.setTitle("Do Something Button", for: UIControl.State())
        doSomethingButton?.titleLabel?.font = UIFont.systemFont(ofSize: 17)
        doSomethingButton?.setTitleColor(UIColor.white, for: UIControl.State())
        doSomethingButton?.isHidden = true
        doSomethingButton?.layer.cornerRadius = 10.0
        doSomethingButton?.layer.borderWidth = 1.0
        doSomethingButton?.layer.borderColor = UIColor.black.cgColor
        doSomethingButton?.layer.shadowOffset = CGSize(width: 10, height: 10)
        doSomethingButton?.layer.shadowOpacity = 8.0
        doSomethingButton?.layer.shadowColor = UIColor.lightGray.cgColor
        
        doSomethingButton?.addTarget(self, action: #selector(ViewController.buttonPressed(_:)), for: UIControl.Event.touchUpInside)
        controlView?.addSubview(doSomethingButton!)
    }
    
    @objc func textFieldDoneEditing(_ sender: AnyObject)
    {
        sender.resignFirstResponder()
    }
    
    @objc func backgroundTap(_ sender: AnyObject)
    {
        nameField?.resignFirstResponder()
        numberField?.resignFirstResponder()
    }
    
    @objc func sliderChanged(_ sender: UISlider)
    {
        let progress = lroundf(sender.value)
        sliderLabel?.text = NSString(format: "%d", progress) as String
    }
    
    @objc func toggleControls(_ sender: UISegmentedControl)
    {
        // 0 ==  switch index
        if(sender.selectedSegmentIndex == 0)
        {
            leftSwitch?.isHidden = false
            rightSwitch?.isHidden = false
            doSomethingButton?.isHidden = true
        }
        else
        {
            leftSwitch?.isHidden = true
            rightSwitch?.isHidden = true
            doSomethingButton?.isHidden = false
        }
    }
    
    @objc func switchChanged(_ sender: UISwitch)
    {
        let setting: Bool = sender.isOn
        leftSwitch?.setOn(setting, animated: true)
        rightSwitch?.setOn(setting, animated: true)
    }
    
    @objc func buttonPressed(_ sender: AnyObject)
    {
        let actionSheet: UIActionSheet = UIActionSheet(title: "A",
            delegate: self,
            cancelButtonTitle: "No way",
            destructiveButtonTitle: "Yes, I'am Sure!",
            otherButtonTitles:"")
        actionSheet.show(in: self.view)
    }
    
    func actionSheet(_ actionSheet: UIActionSheet, didDismissWithButtonIndex buttonIndex: Int)
    {
        if(buttonIndex != actionSheet.cancelButtonIndex)
        {
            var msg: NSString = ""
            let text = nameField?.text as String?
            let coun = text as NSString?
            if(  coun?.length > 0)
            {
                msg = NSString(format: "You can breath easy, %@, everything went OK", nameField!.text!)
            }
            else
            {
                msg = "You can breath easy, everything went OK."
            }
            
            let alert: UIAlertView = UIAlertView(title: "Something was done",
                message: msg as String,
                delegate: nil,
                cancelButtonTitle: "Phew",
                otherButtonTitles: "")
            alert.show()
        }
    }
}

