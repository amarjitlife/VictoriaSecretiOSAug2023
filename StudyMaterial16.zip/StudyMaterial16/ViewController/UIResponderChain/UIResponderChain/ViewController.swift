//
//  ViewController.swift
//  UIResponderChain
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var leftView: UIView?
    var centerView: CenterView?
    var rightView: RightView?
    
    convenience init()
    {
        self.init(nibName: nil, bundle: nil)
    }
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        configureLeftView()
        configureCenterView()
        configureRightView()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureLeftView() {
        self.leftView = UIView(frame: CGRect(x: self.view.bounds.origin.x,
                                             y: self.view.bounds.origin.y,
                                             width: self.view.bounds.size.width/3,
                                             height: self.view.bounds.size.height))
        self.leftView!.backgroundColor = UIColor.lightGray
        self.view.addSubview(self.leftView!)
        
        let titleL = titleLabel()
        titleL.text = "Left View"
        self.leftView!.addSubview(titleL)
                
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(self.handleSingleTapGestureNew(_:)))
        
        singleTap.numberOfTapsRequired = 2
        singleTap.numberOfTouchesRequired = 1
        
        self.view.addGestureRecognizer(singleTap)
    }

    @objc func handleSingleTapGestureNew(_ recognizer: UITapGestureRecognizer)
    {
        if(recognizer.state == UIGestureRecognizer.State.ended)
        {
            let alertView = UIAlertView(title: "Single Tap",
                message: "View Controller View Responder",
                delegate: nil,
                cancelButtonTitle: "OK")
            alertView.show()
        }
    }
    
    func configureCenterView() {
        self.centerView = CenterView(frame: CGRect(x: self.view.bounds.size.width/3,
            y: self.view.bounds.origin.y,
            width: self.view.bounds.size.width/3,
            height: self.view.bounds.size.height))
        self.centerView!.backgroundColor = UIColor.blue
        self.view.addSubview(self.centerView!)
        
        let titleL = titleLabel()
        titleL.text = "Center View"
        self.centerView!.addSubview(titleL)
    }
    
    func configureRightView()
    {
        self.rightView = RightView(frame: CGRect(x: 2 * (self.view.bounds.size.width/3),
            y: self.view.bounds.origin.y,
            width: self.view.bounds.size.width/3,
            height: self.view.bounds.size.height))
        self.rightView!.backgroundColor = UIColor.orange
        self.view.addSubview(self.rightView!)
        
        let titleL = titleLabel()
        titleL.text = "Right View"
        self.rightView!.addSubview(titleL)
    }
    
    func titleLabel() -> UILabel
    {
        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 100, height: 50))
        label.textColor = UIColor.white
        label.font = UIFont.systemFont(ofSize: 14)
        label.textAlignment = NSTextAlignment.center
        label.backgroundColor = UIColor.clear
        return label
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?)
    {
         print("%s %s", #function, #file)
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?)
    {
         print("%s %s", #function, #file)
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?)
    {
         print("%s %s", #function, #file)
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?)
    {
         print("%s %s", #function, #file)
    }
}

