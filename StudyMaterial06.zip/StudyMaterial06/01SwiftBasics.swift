// Compile Swift Code
// 		swiftc 01SwiftBasics.swift -o basics
// Run Swift Code
//		./basics

//____________________________________________________________
//
// DESIGN PRINCIPLE
//		DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY
//
//____________________________________________________________
//____________________________________________________________

// Immutable State
let maximumNumberOfLoginAttemps = 10
// Mutable State
var currentLogingAttemps = 0
var x = 0.0, y = 0.0, z = 1.0
print(x, y ,z )

// Type Annotation
var wecomeMessage: String
// error: variable 'wecomeMessage' used before being initialized
// print( wecomeMessage )
wecomeMessage = "Good Morning"
print( wecomeMessage )

// Identifier Is Any Unicode String
//		Unicode Character Consists of Unicode Points

let pi = 3.1415
let 𝝿 = 3.1415
print( pi )
print( 𝝿 )

//____________________________________________________________
let namaste = "नमस्ते"
print( namaste )

let नमस = 1111
print( नमस )

let tamilSymbol = "௶"
print( tamilSymbol )

let vanakam = "வணக்கம்"
print( vanakam )

let வணக்கம் = "Vanakam"
print( வணக்கம் )

let heart = "♥"
print( heart )

//____________________________________________________________
let base10 = 17
let base2 = 0b10001
let base8 = 0o21
let base16 = 0x11

print( base10 )
print( base2 )
print( base8 )
print( base16 )

//____________________________________________________________
let three = 3
let pointData = 0.14159

// error: binary operator '+' cannot be applied to operands of type 'Int' and 'Double'
// let piAgain = three + pointData

let piAgain = Double( three )  + pointData
print( piAgain )

let integerPi = Int( piAgain )
print( integerPi )

typealias AudioSample = UInt16
var micAudioAmplitude: AudioSample  = 900

print( micAudioAmplitude )

//____________________________________________________________
// Bookean Type and Boolean Expressions

let organgesAreOrange = true
let turnipsAreDeclicious = false

if turnipsAreDeclicious {
	print("Delicious Delicious...")
} else {
	print("Aweful....")
}

if organgesAreOrange || turnipsAreDeclicious {
	print("Delicious Delicious... Oranges")
} else {
	print("Aweful....")
}

let value = -10

//error: type 'Int' cannot be used as a boolean; test for '!= 0' instead
// if ( value ) {

// In Swift Expression Is Boolean Expression
// if ( Expression ) {} else {}

if ( value == -10 ) {
	print("Balleee Balleee")
} else {
	print("Oyeee Hoyeee")
}


//____________________________________________________________
// Tuple Types

// Tuple Of Two Values Of Type Int and String
var http404Error = (404, "Not Found")
var http404ErrorAgain: (Int, String) = (404, "Not Found")

print( http404Error )
print( http404ErrorAgain )

// Accessing TUple Members
print("Status Code : \( http404Error.0 )")
print("Status Message : \( http404Error.1 )")

// Tuple Unpacking/Decluttering
let ( code, message ) = http404Error
print("Status Code : \(code)")
print("Status Message : \(message)")

let ( codeAgain, _ ) = http404Error
print("Status Code : \(codeAgain )")

//Named Tuple
let httpError = ( statusCode: 404, statusMessage: "Not Found")
print("Status Code : \( httpError.statusCode )")
print("Status Message : \( httpError.statusMessage )")

// error: cannot assign value of type '(Int, Int, Int, String)' to type '(Int, String)'
// http404Error = (100, 404, 5000, "Not Found")

//____________________________________________________________
//
// NULLABILIITY AND NON NULLABILITY
//____________________________________________________________

var something : Int = 90
print( something )
// something = nil 

var somethingAgain: Int? = 99
somethingAgain = nil 
print( somethingAgain ?? 0 ) // print ( if somethingAgain == nil { somethingAgain = 0 }  )

// Default Type Will Be Non Optional
var greetings: String = "Good Morning"
print( greetings )

// greetings = nil
// print( greetings )
var greetingsAgain: String? = "Good Morning"
print( greetingsAgain ?? "Unknown") // print ( if greetingAgain == nil { greetingAgain = "Unknon" } )

greetingsAgain = nil
print( greetingsAgain ?? "Unknown" )

let possibleNumber = "1234"
// error: value of optional type 'Int?' must be unwrapped to a value of type 'Int'
// let convertedNumber: Int = Int( possibleNumber )

// covertedNumber Is Of Type Int?
let convertedNumber = Int( possibleNumber )
let convertedNumberAgain: Int? = Int( possibleNumber )

// warning: expression implicitly coerced from 'Int?' to 'Any'
// print( convertedNumber )
print( convertedNumberAgain ?? 0)
print( convertedNumber ?? 0 )

if convertedNumber != nil {
	print("\(possibleNumber) String Converted To \(convertedNumber ?? 0)")
} else {
	print("Found Nothingnes..")
}


//____________________________________________________________
//
// DESIGN PRINCIPLE
//		DESIGN TOWARDS IMMUTABILITY RATHER THAN MUTABILITY
// 		i.e. Things Which Are Not Suppose To Change
//				MUST BE IMMUTABLE
//____________________________________________________________

// Optional Binding
// Idioms
// actualNumber will Contain Unwarpped Value
//		Hence Type of actualNumber will be Int
//		Moreover actualNumber Is Local To if Block

if let actualNumber = Int( possibleNumber ) {
	print("\(possibleNumber) String Converted To \( actualNumber )")
} else {
	print("Found Nothingnes..")
}

if let actualNumber = Int( possibleNumber ) {
if var actualNumber = Int( possibleNumber ) {
	actualNumber = actualNumber + 1;
	print("\(possibleNumber) String Converted To \( actualNumber )")
} else {
	print("Found Nothingnes..")
}


// For Above if-else Idiom
// Compiler Will Generate Following Code 
let generatedConvertedNumber = Int( possibleNumber )
if  generatedConvertedNumber != nil {
	let actualNumber = generatedConvertedNumber!
	print("\(possibleNumber) String Converted To \( actualNumber )")
} else {
	print("Found Nothingnes..")
}

let possibleNumber1: String? = "1234"
// error: value of optional type 'String?' must be unwrapped to a value of type 'String'
// let convertedNumber1 = Int( possibleNumber1 )

// let convertedNumberAgain: Int? = Int( possibleNumber )

// Optional Binding
if let firstNumber = Int("42"), let secondNumber = Int("100"), firstNumber < secondNumber {
	print("\(firstNumber) Is Less Than \(secondNumber)")	
} else {
	print("Something Unacceptable Happened")
}

// Compiler Will Generate Following Code For Above IDIOM
let tempFirstNumber = Int("42")
let tempSecondNumber = Int("100")
if tempFirstNumber != nil && tempSecondNumber != nil {
	let firstNumber = tempSecondNumber!
	let secondNumber = tempSecondNumber!
 
 	if firstNumber < secondNumber {
		print("\(firstNumber) Is Less Than \(secondNumber)")	
	}

} else {
	print("Something Unacceptable Happened")
}

//____________________________________________________________

let aa: Int? = 44
let bb: Int? = nil
let cc: Int? = 88

if let A = aa, let B = bb, let C = cc {
	print( A, B, C )
} else {
	print("Nothingness Found: One Of aa, bb, cc Is nil")
}

// Compiler Will Generate What Code For Above Idiom?

//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
