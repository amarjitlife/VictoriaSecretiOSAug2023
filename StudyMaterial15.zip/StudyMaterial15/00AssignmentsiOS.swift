__________________________________________________________________

DAY 01
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Commands From First 95 Pages 

		Reference: Linux Pocket Guide, Oreilly Publication
				By Daniel J Barret

__________________________________________________________________

DAY 02
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBasicsTutorial.pdf

__________________________________________________________________

DAY 03
__________________________________________________________________

	Assignment A1: Reading and Experimentation Assignment
		Read and Experiment Git Commands  

		GitBranchingNotes.pdf

__________________________________________________________________

DAY 04
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Java
			Chapter 1: Object-Oriented Design
			Chapter 2: Designing Classes with a Single Responsibility

		Reference Book:
			Practical Object-Oriented Design: An Agile Primer
				By Sandi Metz

	Assignment A2: Reading and Experimentation Assignment
		Read and Experiment Git Commands For Work Flow

		Reference Notes:
			GitBranchingNotes.pdf
			GitBranchingModelNotes.pdf
			GitFundamentalsNotes.pdf
			GitOnServerNotes.pdf

		Reference Links:
			https://nvie.com/posts/a-successful-git-branching-model/
			https://www.atlassian.com/git/tutorials/comparing-workflows/gitflow-workflow

__________________________________________________________________

DAY 05 + SUNDAY
__________________________________________________________________

	// NOTE NOTE: Assignment A1 and Assignment A2 Are COMPULSORY
	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In C
			Chapter 02: Types, Operators and Expressions
			Chapter 05: Pointers And Arrays

		Reference Book:
			The C Programming Language, 2nd Edition
				Brain Kernigham and Dennis Ritchie

	Assignment A2: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Java
			Chapter 1: Object-Oriented Design
			Chapter 2: Designing Classes with a Single Responsibility
			Chapter 3: Managing Dependencies
			Chapter 4: Creating Flexible Interfaces 

		Reference Book:
			Practical Object-Oriented Design: An Agile Primer
				By Sandi Metz

	Assignment A3: Reading UML Diagrams
		Reference Links:
			https://www.visual-paradigm.com/guide/uml-unified-modeling-language/uml-class-diagram-tutorial/
			https://www.lucidchart.com/pages/uml-sequence-diagram
			https://creately.com/guides/sequence-diagram-tutorial/
			https://developer.ibm.com/articles/the-sequence-diagram/

__________________________________________________________________

DAY 06 
__________________________________________________________________

	// NOTE NOTE: Assignment A1 and Assignment A2 Are COMPULSORY
	Assignment A1: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In C
			Chapter 02: Types, Operators and Expressions
			Chapter 03: Control Structures
			Chapter 05: Pointers And Arrays

		Reference Book:
			The C Programming Language, 2nd Edition
				Brain Kernigham and Dennis Ritchie

	Assignment A2: Reading, Thinking and Experimentation Assignment
		Read, Think and Experiment Code In Swift Till Now DONE!

		Reference Links:
			https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/

	Assignment A3: Thinking and Experimentation Assignment
		Question 01: Do Original C ( K&R C ) Have Boolean Type?
				Compare With Swift And Reason Design Choices!
		
		Question 02: Syntax and Semantics of if-else Construct in C, C++, Java and Python
				Compare With Swift And Reason Design Choices!
		
		Question 03: Syntax and Semantics of Tuple in Python vs Swift
				Compare With Swift And Reason Design Choices!

		Question 04: Experiment with Unwrapping In Swift
				Design Best Practices For Unwrapping!

__________________________________________________________________

DAY 07 
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Swift Assignment
		Read, Think and Experiment Code In Swift Till Now DONE!

		Reference Links:
			https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/
			https://docs.swift.org/swift-book/documentation/the-swift-programming-language/basicoperators/
			https://docs.swift.org/swift-book/documentation/the-swift-programming-language/stringsandcharacters/
			https://docs.swift.org/swift-book/documentation/the-swift-programming-language/collectiontypes/

	Assignment A2: Thinking and Experimentation Assignment
		Question 01: Compare Modulus Operator ( % ) In C, C++, Java and Swift
				Compare With Swift And Reason Design Choices!
		
		Question 02: Compare Strings With Equality Operator	In C, C++, Java, Python, Swift
				Compare With Swift And Reason Design Choices!

		Question 02: Compare Tuples With Comparison Operator In C, C++, Java, Python, Swift
				Compare With Swift And Reason Design Choices!

__________________________________________________________________

DAY 08
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Swift Assignment
		Read, Think and Experiment Code In Swift Till Now DONE!

		Reference Links:
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/collectiontypes/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/controlflow/#Control-Transfer-Statements
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/functions/#Functions-With-an-Implicit-Return

	Assignment A2: REVISE AND Thinking and Experimentation Assignment
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays

		Reference Book:
			The C Programming Language, 2nd Edition
				Brain Kernigham and Dennis Ritchie

	Assignment A3: Data Structure Reading, Thinking and Experimentation Assignment
		Chapter 09: Tables and Information Retrieval
		Chapter 10: Binary Trees

		Reference Book:
			Data Structures and Program Design in C, 2nd Edition
			Data Structures and Program Design in C++ 
				By Robert L Kruse		

__________________________________________________________________

DAY 09
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Swift Assignment
		Read, Think and Experiment Code In Swift Till Now DONE!

		Reference Links:
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/closures/

	Assignment A2: REVISE AND Thinking and Experimentation Assignment
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays

		Reference Book:
			The C Programming Language, 2nd Edition
				Brain Kernigham and Dennis Ritchie

	Assignment A3: Data Structure Reading, Thinking and Experimentation Assignment
		Chapter 09: Tables and Information Retrieval
		Chapter 10: Binary Trees

		Reference Book:
			Data Structures and Program Design in C, 2nd Edition
			Data Structures and Program Design in C++ 
				By Robert L Kruse		


__________________________________________________________________

DAY 10
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Swift Assignment
		Read, Think and Experiment Code In Swift Till Now DONE!

		Reference Links:
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/closures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/methods/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/

	Assignment A2: REVISE AND Thinking and Experimentation Assignment
		Read, Think and Experiment Code In C
			Chapter 05: Pointers And Arrays

		Reference Book:
			The C Programming Language, 2nd Edition
				Brain Kernigham and Dennis Ritchie

	Assignment A3: Data Structure Reading, Thinking and Experimentation Assignment
		Chapter 09: Tables and Information Retrieval
		Chapter 10: Binary Trees

		Reference Book:
			Data Structures and Program Design in C, 2nd Edition
			Data Structures and Program Design in C++ 
				By Robert L Kruse		

__________________________________________________________________

DAY 11
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Swift Assignment
		Read, Think and Experiment Code In Swift Till Now DONE!

		Reference Links:
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/inheritance/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/initialization/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/deinitialization
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/optionalchaining
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/errorhandling/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/typecasting/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/nestedtypes/
		
	  	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/extensions/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/

	Assignment A2: REVISION, Thinking and Experimentation ALL SWIFT CODE DONE TILL NOW
		Read, Think and Experiment Code In Swift Till Now DONE!

		Reference Links:
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/closures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/methods/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/


	Assignment A3: Data Structure Reading, Thinking and Experimentation Assignment
		Chapter 09: Tables and Information Retrieval
		Chapter 10: Binary Trees

		Reference Book:
			Data Structures and Program Design in C, 2nd Edition
			Data Structures and Program Design in C++ 
				By Robert L Kruse		

__________________________________________________________________

DAY 13
__________________________________________________________________

	Assignment A1: Reading, Thinking and Experimentation Swift Assignment
		Read, Think and Experiment Code In Swift Till Now DONE!

		Reference Links:		
	  	https://docs.swift.org/swift-book/documentation/the-swift-programming-language/extensions/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/protocols/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/generics/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/accesscontrol/

	Assignment A2: REVISION, Thinking and Experimentation ALL SWIFT CODE DONE TILL NOW
		Read, Think and Experiment Code In Swift Till Now DONE!

		Reference Links:
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/closures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/enumerations/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/classesandstructures/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/methods/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/properties/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/subscripts/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/inheritance/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/initialization/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/deinitialization
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/optionalchaining
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/errorhandling/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/typecasting/
		https://docs.swift.org/swift-book/documentation/the-swift-programming-language/nestedtypes/


__________________________________________________________________

DAY 14
__________________________________________________________________

	Assignment A1: iOS Reading, Thinking and Experimentation Assignment
		Complete Following Modules THROUGHLY From iPhone Application Programming Guide, Apple
			Module: About iOS App Programming
			Module: App Design Basics
			Module: Core App Objects
			Module: App States and Multitasking
			Module: App-Related Resources

		Reference Book:
			iPhone Application Programming Guide, Apple

	Assignment A2: Thinking and Experimentation Assignment
			Improve More User Interface Fun Example
				0. Create New Project To Write Improved Code
				1. Find and Fix Bugs
				2. Do Better Swift Code Design
				3. Replace Deprecated APIs with Newer APIs 
				4. Experiments With Addition Of 2/3 More Newers View Controls
						And Make Them Work!

	Assignment A3: REVISION, Thinking and Experimentation ALL SWIFT CODE DONE TILL NOW
		Read, Think and Experiment Code In Swift Till Now DONE!

__________________________________________________________________

DAY 15
__________________________________________________________________

	Assignment A1: iOS Reading, Thinking and Experimentation Assignment
		Complete Following Modules THROUGHLY From iPhone Application Programming Guide, Apple
			Module: About iOS App Programming
			Module: App Design Basics
			Module: Core App Objects
			Module: App States and Multitasking
			Module: App-Related Resources

		Reference Book:
			iPhone Application Programming Guide, Apple

	Assignment A2: Thinking and Experimentation Assignment
			Improve More User Interface Fun Example
				0. Create New Project To Write Improved Code
				1. Find and Fix Bugs
				2. Do Better Swift Code Design
				3. Replace Deprecated APIs with Newer APIs 
				4. Experiments With Addition Of 2/3 More Newers View Controls
						And Make Them Work!
	
	Assignment A3: Reading, Thinking and CODING In Swift Assignment
		Chapter 01 To Chapter 10
			Read All Chapters
			Code All Examples
			Solve All Challenges At The End Of Chapters

			TableView, TableViewControler Example Code Using CollectionView
			Comapare and Reason Design Choices
				CollectionView/CollectionViewController Vs. TableView/TableViewControler

		Reference Book:
			iOS Programming Big Nerd Ranch Guide, 7E

__________________________________________________________________
__________________________________________________________________
__________________________________________________________________
__________________________________________________________________
__________________________________________________________________
__________________________________________________________________










    