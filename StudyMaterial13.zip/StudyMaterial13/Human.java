
// Superpower Interface Defines
// 		What To Do?
interface Superpower {
	void fly();
	void saveWorld();
}

// Spiderman, Superman,... Are Concrete Classes It Defines
// 		How, When, Where, Which Way To Do?
class Spiderman implements Superpower {
	public void fly() 		 { System.out.println("Fly Like Spiderman!!!"); }
	public void saveWorld() { System.out.println("Save World Like Spiderman!!!"); }	
}

class Superman implements Superpower {
	public void fly() 		 { System.out.println("Fly Like Superman!!!"); }
	public void saveWorld() { System.out.println("Save World Like Superman!!!"); }	
}

class Heman {
	void fly() 		 { System.out.println("Fly Like Heman!!!"); }
	void saveWorld() { System.out.println("Save World Like Heman!!!"); }	
}

class HanumanJi implements Superpower {
	public void fly() 		 { System.out.println("Fly Like HanumanJi!!!"); }
	public void saveWorld() { System.out.println("Save World Like HanumanJi!!!"); }	
}

class Wonderwoman {
	void fly() 		 { System.out.println("Fly Like Wonderwoman!!!"); }
	void saveWorld() { System.out.println("Save World Like Wonderwoman!!!"); }	
}

// SOLID
//		S: Single Responsibiity Design
//			Do One Thing and Very Well

//		O: Open-Close Design
//			Classes Are Open For Extention and CLose For Modifications
//_______________________________________________________

// DESIGN 01: Using Inhertance Mechanism
// class Human extends Spiderman {
// class Human extends Superman {
// class Human extends Heman {
class Human extends Wonderwoman {
	void fly() 		 { super.fly(); }
	void saveWorld() { super.saveWorld(); }
}

// _______________________________________________________
// DESIGN 02: Using Composition Mechanism

class HumanAgain {
	// Injecting Dependency
	// Spiderman power = new Spiderman();
	// Superman power = new Superman();
	Heman power = new Heman();

	void fly() 		 { power.fly(); }
	void saveWorld() { power.saveWorld(); }
}

// _______________________________________________________
// DESIGN 03: Using Composition Mechanism

// Following Design Folows 
//  Single Respobility Design
//	Open - CLose Design
class HumanOnceAgain {
	// Spiderman power = new Spiderman();
	// power Is A Delegate
	Superpower power = null;

	void fly() 		 { if ( power != null ) power.fly(); }
	void saveWorld() { if ( power != null ) power.saveWorld(); }
}

class HumanDemo {
	public static void main( String [] args ) {
		Spiderman spider = new Spiderman();
		spider.fly();
		spider.saveWorld();

		Human veeru = new Human();
		veeru.fly();
		veeru.saveWorld();

		HumanAgain veeruAgain = new HumanAgain();
		veeruAgain.fly();
		veeruAgain.saveWorld();

		HumanOnceAgain veeruOnceAgain = new HumanOnceAgain();
		// Injecting Dependency
		veeruOnceAgain.power = new Spiderman();
		veeruOnceAgain.fly();
		veeruOnceAgain.saveWorld();		

		// Injecting Dependency
		veeruOnceAgain.power = new Superman();
		veeruOnceAgain.fly();
		veeruOnceAgain.saveWorld();		

		// Injecting Dependency
		veeruOnceAgain.power = new HanumanJi();
		veeruOnceAgain.fly();
		veeruOnceAgain.saveWorld();		
	}
}

