// Compile Swift Code
// 		swiftc SwiftHello.swift -o hello
// Run Swift Code
//		./hello

print("Hello World!!!")
