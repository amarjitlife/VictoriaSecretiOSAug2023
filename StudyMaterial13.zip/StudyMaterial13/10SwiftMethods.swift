// Compile Swift Code
//      swiftc 10SwiftMethods.swift -o methods
// Run Swift Code
//      ./methods

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\n\nMember Functions and Member Properties")

class Counter {
	// Instance Member Properties
	var count = 0
	// Instance Member Functions
	func increment() {
		count = count + 1
	}
	// Instance Member Functions
	func incrementBy( amount: Int ) {
		count += amount 
	}
	// Instance Member Functions
	func reset() {
		count = 0
	}
}

let counter = Counter()
print( counter.count )
counter.increment()
counter.incrementBy( amount: 10 )
print( counter.count )
counter.reset()
print( counter.count )


class CounterAgain {
	// Instance Member Properties
	var count = 0
	// Instance Member Functions

    func incrementBy(amount: Int, numberOfTimes: Int) {
        count += amount * numberOfTimes
    }
}

let counter2 = CounterAgain()
print( counter2.count )
counter2.incrementBy(amount: 5, numberOfTimes: 3 )
print( counter2.count )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\n\nPoint Structure Member Functions and Member Properties")

struct Point {
	// Instance Member Properties
    var x = 0.0, y = 0.0
	// Instance Member Functions
    func isToTheRightOfX( x: Double ) -> Bool {
        return self.x > x
    }
}

let somePoint = Point(x: 4.0, y: 5.0)
print( somePoint )
if somePoint.isToTheRightOfX(x: 1.0) {
    print("This point is to the right of the line where x == 1.0")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\n\nPoint2 Structure Member Functions and Member Properties")

struct Point2 {
	// Instance Member Properties
    var x = 0.0, y = 0.0
	// Instance Member Functions

    // func moveByX(deltaX: Double, deltaY:Double) {
    mutating func moveByX(deltaX: Double, deltaY:Double) {
        // error: left side of mutating operator isn't mutable: 'self' is immutable
        self.x += deltaX 
        self.y += deltaY
    }
}

var somePoint2 = Point2(x: 1.0, y: 1.0)
print( somePoint2 )
somePoint2.moveByX(deltaX: 2.0, deltaY: 3.0)
print( somePoint2 )

let fixedPoint = Point2(x: 3.0, y: 3.0)
print( fixedPoint )

struct Point3 {
    var x = 0.0, y = 0.0
    // error: cannot assign to value: 'self' is immutable
    // func moveByX(deltaX: Double, deltaY: Double) {
    mutating func moveByX(deltaX: Double, deltaY: Double) {
        self = Point3(x: x + deltaX, y: y + deltaY)
    }
}

var somePoint3 = Point3(x: 1.0, y: 1.0)
print( somePoint3 )
somePoint3.moveByX(deltaX: 100.0, deltaY: 100.0)
print( somePoint3 )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!


enum TriStateSwitch {
    case Off, Low, High
	
	// Instance Member Functions
	// error: cannot assign to value: 'self' is immutable
    // func next() {
    mutating func next() {
        switch self {
        case .Off:
            self = .Low
        case .Low:
            self = .High
        case .High:
            self = .Off
        }
    }
}

var ovenLight = TriStateSwitch.Low
print( ovenLight )

ovenLight.next()
print( ovenLight )

ovenLight.next()
print( ovenLight )

ovenLight.next()
print( ovenLight )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

class SomeClass {
	// Type Member Functions
	//		Binded With Type Hence Accessed Using Type
    class func someTypeMethod() {
        // type method implementation goes here
        print("SomeClass Type Member Function Called...")
    }
}

SomeClass.someTypeMethod()

struct LevelTracker {
	// Type Member Variable
    static var highestUnlockedLevel = 1

	// Type Member Functions
    static func unlockLevel(level: Int) {
        if level > highestUnlockedLevel { highestUnlockedLevel = level }
    }

	// Type Member Functions
    static func levelIsUnlocked(level: Int) -> Bool {
        return level <= highestUnlockedLevel
    }

	// Instance Member Variable
    var currentLevel = 1

	// Instance Member Functions
    mutating func advanceToLevel(level: Int) -> Bool {
        if LevelTracker.levelIsUnlocked(level: level) {
            currentLevel = level
            return true
        } else {
            return false
        }
    }
}

var levelTrackerInstance = LevelTracker()

// Accessing Instance Members: Using Instance
print( levelTrackerInstance.currentLevel )
print( levelTrackerInstance.advanceToLevel( level: 10 ) )
print( levelTrackerInstance.currentLevel )

// Accesing Type Members : Using Type
print( LevelTracker.highestUnlockedLevel )
print( LevelTracker.unlockLevel( level: 88 ) )
print( LevelTracker.levelIsUnlocked( level: 99 ) )
print( LevelTracker.highestUnlockedLevel )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

class Player {
    var tracker = LevelTracker()
    let playerName: String

    func completedLevel(level: Int) {
        LevelTracker.unlockLevel(level: level + 1)
        _ = tracker.advanceToLevel(level: level + 1)
    }

    init(name: String) {
        playerName = name
    }
}

var player = Player(name: "Argyrios")
player.completedLevel(level: 1)
print("highest unlocked level is now \(LevelTracker.highestUnlockedLevel)")

player = Player(name: "Beto")
if player.tracker.advanceToLevel(level: 6) {
    print("player is now on level 6")
} else {
    print("level 6 has not yet been unlocked")
}

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

