// Compile Swift Code
// 		swiftc 07SwiftClosures.swift -o closures
// Run Swift Code
//		./closures

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print( "\nSorted Polymorpic Function With Function Arguments")

let names = ["Chris", "Alex", "Ewa", "Barry", "Daniella"]

func backwards( s1: String, s2: String ) -> Bool {
	return s1 > s2
}

func forwards( s1: String, s2: String ) -> Bool {
	return s1 < s2
}

print( names )

// Polymorphic Functions
//		Using Mechanism: By Passing Behaviour To Behaviour
//					i.e. By Passing Function TO Function
var reversed = names.sorted( by: backwards )
print( reversed )
print( names )

var sortedNames = names.sorted( by: forwards )
print( sortedNames )

// names.sorted( by: (String, String) -> Bool )
// numbers.sorted( by: (Int, Int) -> Bool )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print( "\nSorted Function With Lambda/Closure Arguments")

reversed = names.sorted( by: { (s1: String, s2: String ) -> Bool in return s1 > s2} )
print( reversed )

sortedNames = names.sorted( by: { (s1: String, s2: String ) -> Bool in return s1 < s2} )
print( sortedNames )

// Inferring Type from from Context
reversed = names.sorted( by: { (s1, s2) in return s1 > s2 } )
print( reversed )

// Implicit returns from Single-Expression Closures
reversed = names.sorted( by: { (s1, s2) in s1 > s2 } )
print( reversed )

// Shorthand Argument Names
reversed = names.sorted( by: { $0 > $1 } )
print( reversed )

// Operator Function
reversed = names.sorted( by: > )
print( reversed )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Trailing Lambda/Closure

print( "\nTrailing Lambda/Closure" )

func doSomething() {
	print("Doing Something...")
}

func someFunction( something: () -> () ) {
	print("Calling Passed Function As A Argument...")
	something()
}

someFunction( something: doSomething )

// {} Is Lamdba/Closure With NO Arguments and NO Return Value
let someClosure = {}
let someClosureAgain: () -> () = {}

let someClosure1 = { print("Doing Something More...") }
let someClosureAgain1: () -> () = { print("Doing Something More...") }

someFunction( something: someClosure1 )
someFunction( something: someClosureAgain1 )

someFunction( something: { print("Doing Something More...") } )

// Trailing Lambda
someFunction() { print("Doing Something More...") } 

someFunction() { 
	print("Doing Something More...") 
} 


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

let digitNames = [0: "Zero", 1: "One", 2: "Two", 3: "Three", 4:"Four", 
				  5: "Five", 6:"Six", 7: "Seven", 8: "Eight", 9: "Nine"]

print( digitNames )

let numbers = [16, 58, 510]

func transformData(number: Int) -> String {
		var number = number
		var output = ""
		repeat {
			output = digitNames[ number % 10 ]! + output
			number /= 10 
		} while number > 0
		
		return output
}

let strings = numbers.map( transformData )
print( strings )

let transformDataLambda = {
	( number : Int ) -> String in
		var number = number
		var output = ""
		repeat {
			output = digitNames[ number % 10 ]! + output
			number /= 10 
		} while number > 0
		
		return output
}


let stringsAgain = numbers.map( transformDataLambda )
print( stringsAgain )

let stringsOnceAgain = numbers.map( {
	( number ) -> String in
		var number = number
		var output = ""
		repeat {
			output = digitNames[ number % 10 ]! + output
			number /= 10 
		} while number > 0
		
		return output
} )

print( stringsOnceAgain )

// Trailing Lambda Syntax
let stringsOnceMore = numbers.map() {
	( number ) -> String in
		var number = number
		var output = ""
		repeat {
			output = digitNames[ number % 10 ]! + output
			number /= 10 
		} while number > 0
		
		return output
} 

print( stringsOnceMore )


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// CAPTURING VALUES

print("\n\n Function Returning A Function ")

// fun makeIncrementor( amount: Int ) : () -> Int {
func makeIncrementor( amount: Int ) -> () -> Int {
    var runningTotal = 0 // Local Variable
    // Local Function : Function Defined Insdie Function
	// fun incrementor() : Int {	
    func incrementor() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return incrementor
    // Local Variable Will Not Exists After Exit Of Function
}

let incrementorByTen: () -> Int = makeIncrementor( amount: 10 )
print( incrementorByTen() )
print( incrementorByTen() )
print( incrementorByTen() )

let incrementorBySeven: () -> Int = makeIncrementor( amount: 7 )
print( incrementorBySeven() )
print( incrementorBySeven() )

// Reference Assignment 
//		i.e. Both Are Pointing To The Same Objects
let incrementorByTenAgain = incrementorByTen
print( incrementorByTenAgain() )
print( incrementorByTenAgain() )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Closures Are Reference Types


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!
