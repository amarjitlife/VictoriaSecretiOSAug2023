
// Compile Swift Code
//     swiftc 19SwiftExtensions.swift -o extensions
// Run Swift Code
//      ./extensions

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\nExtentions On Double Type")

extension Double {
	var km: Double { 
		// get() {
			return self * 1_000.0 
		// }
	}
	var m : Double { return self }
	var cm: Double { return self / 100.0 }
	var mm: Double { return self / 1_000.00 }
	var ft: Double { return self / 3.28084 } 
}

let oneInch = 25.4.mm 
print("\tOne Ince Is \(oneInch) Meters ")

let threeFeet = 3.ft
print("\tThree feet is \(threeFeet) Meters")

let aMarathon = 42.km + 195.m
print("\tMatathon Is \(aMarathon) Meters Long")

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\nExtention On Type Rect: Adding Initialsers")

struct Size {
    var width = 0.0, height = 0.0
}

struct Point {
    var x = 0.0, y = 0.0
}

struct Rect {
    var origin: Point = Point()
    var size: Size    = Size()

    // init(center: Point, size: Size) {
    //     let originX = center.x - (size.width / 2)
    //     let originY = center.y - (size.height / 2)
    //     self.init(origin: Point(x: originX, y: originY), size: size)
    // }
}

let defaultRect = Rect()
// Above Line Is Equivalent To Following
// let defaultRect = Rect(origin: Point(), size: Size())
print( defaultRect )

// In Java/C++ Default Constructor Generated With No Arguments
// In Swift By Default Memberwise Initialiser/Constructor Generated
//          Which Will Initialise All The Members
let memberwiseRect = Rect(origin: Point(x: 2.0, y:2.0), size: Size(width: 5.0, height: 5.0))
print( memberwiseRect )

extension Rect {
    // Constructor Overloading Mechanisms Based On 
    //      1. Number of Arguments
    //      2. Types of Arguments
    //      3. Label of Arguments
    init(center: Point, size: Size) {
        let originX = center.x - (size.width / 2)
        let originY = center.y - (size.height / 2)
        self.init(origin: Point(x: originX, y: originY), size: size)
    }
}

let centerRect = Rect(center: Point(x: 4.0, y: 4.0), size: Size(width: 3.0, height:3.0))
print( centerRect )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\nExtention On Type Int: Adding Function/Method")

// Methods

extension Int {
    func repetitions( task: () -> () ) {
        for _ in 0..<self {
            task()
        }
    }
}

3.repetitions( task: { print("Hello!") } )
// Trailing Closure/Lambda Syntax
3.repetitions { print("Goodbye!") }


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\nExtention On Type Int: Adding Function/Method")

// Methods

extension Int {
    mutating func changeValue( change: Int ) {
        self = self + change
    }
}

// var value = 3.changeValue( change: 10 )
// print( value )
var valueAgain =  3
valueAgain.changeValue( change: 100 )
print( valueAgain )

extension Int {
    mutating func square() {
        self = self * self
    }
}

var someInt = 3
someInt.square()
print( someInt )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\nExtention On Type Int: Adding Subscript Operator")

extension Int {
    subscript( digitIndex: Int ) -> Int {
        var digitIndex = digitIndex
        var decimalBase = 1
            while digitIndex > 0 {
                decimalBase *= 10
                digitIndex = digitIndex - 1
            }
            return ( self / decimalBase ) % 10
    }
}

var digit: Int

print("Number: 987656789 Digits Are...")
digit = 987656789[0]
print( digit )
digit = 987656789[1]
print( digit )
digit = 987656789[2]
print( digit )
digit = 987656789[3]
print( digit )


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

print("\nExtention On Type Int: Adding Kind Check")

extension Int {
    enum Kind {
        case Negative, Zero, Positive
    }

    var kind: Kind {
        switch self {
        case 0:
            return .Zero
        case let x where x > 0:
            return .Positive
        default:
            return .Negative
        }
    }
}

func printIntegerKinds(numbers: [Int]) {
    for number in numbers {
        switch number.kind {
        case .Negative:
            print("- ", terminator: "")
        case .Zero:
            print("0 ", terminator: "")
        case .Positive:
            print("+ ", terminator: "")
        }
    }
}

let numbers = [10, -10, 0, 99, 0, 80, 100, -999]
printIntegerKinds( numbers: numbers )

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________

//__________________________________________________________
//__________________________________________________________

