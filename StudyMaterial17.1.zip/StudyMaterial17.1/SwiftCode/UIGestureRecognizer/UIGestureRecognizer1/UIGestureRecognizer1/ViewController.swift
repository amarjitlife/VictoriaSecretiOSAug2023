//
//  ViewController.swift
//  UIGestureRecognizer1
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    var imageView: UIImageView?
    
    override func loadView()
    {
        super.loadView()
        configureSingleTapGesture()
        configureDoubleTapGesture()
        let singleTap: UITapGestureRecognizer = self.view.gestureRecognizers![0] as UITapGestureRecognizer
        singleTap.requireGestureRecognizerToFail(self.view.gestureRecognizers![1] as UITapGestureRecognizer)
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureSingleTapGesture()
    {
        let singleTap = UITapGestureRecognizer(target: self, action: "handleSingleTapGestureRecognizer:")
        singleTap.numberOfTapsRequired = 1;
        singleTap.numberOfTouchesRequired = 1
        self.view.addGestureRecognizer(singleTap)
    }
    
    func configureDoubleTapGesture()
    {
        let doubleTap = UITapGestureRecognizer(target: self, action: "handleDoupleGestureRecognizer:")
        doubleTap.numberOfTapsRequired = 2;
        doubleTap.numberOfTouchesRequired = 1
        self.view.addGestureRecognizer(doubleTap)
    }
    
    func configurePanGesture()
    {
        let pan: UIPanGestureRecognizer = UIPanGestureRecognizer(target: self, action: "handlePanGestureRecognizer:")
        pan.minimumNumberOfTouches = 1
        pan.maximumNumberOfTouches = 1
        self.imageView!.addGestureRecognizer(pan)
    }
    
    func configurePinchGesture()
    {
        let pinch: UIPinchGestureRecognizer = UIPinchGestureRecognizer(target: self, action: "handlePinchGestureRecognizer:")
        self.imageView!.addGestureRecognizer(pinch)
    }
    
    func handleSingleTapGestureRecognizer(sender: UITapGestureRecognizer)
    {
        if(sender.state == UIGestureRecognizerState.Ended)
        {
            if(self.imageView == nil)
            {
                self.imageView = UIImageView(image: UIImage(named: "apple.png"))
                self.imageView!.frame = CGRectMake(0, 0, 150, 150)
                self.imageView!.center = self.view.center
                self.imageView!.userInteractionEnabled = true
                self.view.addSubview(self.imageView!)
                configurePanGesture()
                configurePinchGesture()
            }
        }
    }
    
    func handleDoupleGestureRecognizer(sender: UITapGestureRecognizer )
    {
        if(sender.state == UIGestureRecognizerState.Ended)
        {
            if(self.imageView != nil)
            {
                self.imageView!.removeFromSuperview()
                self.imageView = nil
            }
        }
    }
    
    func handlePanGestureRecognizer(sender: UIPanGestureRecognizer)
    {
        if(sender.state == UIGestureRecognizerState.Changed)
        {
            let translation: CGPoint = sender.translationInView(sender.view!)
            sender.view?.center = CGPointMake(sender.view!.center.x + translation.x,
                sender.view!.center.y + translation.y)
            sender.setTranslation(CGPointMake(0, 0), inView: sender.view)
        }
    }
    
    func handlePinchGestureRecognizer(sender: UIPinchGestureRecognizer)
    {
        if(sender.state == UIGestureRecognizerState.Changed)
        {
            let scale: CGFloat = sender.scale
            sender.view?.transform = CGAffineTransformScale(sender.view!.transform, scale, scale)
            sender.scale = 1
        }
    }

}

