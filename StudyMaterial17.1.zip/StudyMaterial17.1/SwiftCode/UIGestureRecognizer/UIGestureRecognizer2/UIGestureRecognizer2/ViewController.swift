//
//  ViewController.swift
//  UIGestureRecognizer2
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit
import QuartzCore

class ViewController: UIViewController {
    
    var firstView: UIView?
    var secondView: UIView?
    
    override func loadView()
    {
        super.loadView()
        
        self.secondView = UIView(frame: self.view.bounds)
        self.secondView!.backgroundColor = UIColor.orangeColor()
        self.secondView!.hidden = true
        self.view.addSubview(self.secondView!)
        
        var label: UILabel = titleLable()
        label.text = "SECOND VIEW"
        label.center = self.secondView!.center
        self.secondView!.addSubview(label)
        
        self.firstView = UIView(frame: self.view.bounds)
        self.firstView!.backgroundColor = UIColor.lightGrayColor()
        self.firstView!.hidden = false
        self.view.addSubview(self.firstView!)
        
        label = titleLable()
        label.text = "FIRST VIEW"
        label.center = self.firstView!.center
        self.firstView!.addSubview(label)
        
        configureLeftSwipeGesture()
        configureRightSwipeGesture()
        configureLongPressGesture()
        
    }
                            
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func configureLeftSwipeGesture()
    {
        let leftSwipe: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self,
            action: "handleLeftSwipeGestureRecognizer:")
        leftSwipe.direction = UISwipeGestureRecognizerDirection.Left
        self.view.addGestureRecognizer(leftSwipe)
    }
    
    func configureRightSwipeGesture()
    {
        let rightSwipe: UISwipeGestureRecognizer = UISwipeGestureRecognizer(target: self,
            action: "handleRightSwipeGestureRecognizer:")
        rightSwipe.direction = UISwipeGestureRecognizerDirection.Right
        self.view.addGestureRecognizer(rightSwipe)
    }
    
    func configureLongPressGesture()
    {
        let longPress: UILongPressGestureRecognizer = UILongPressGestureRecognizer(target: self,
            action: "handleLongPressGestureRecognizer:")
        longPress.numberOfTouchesRequired = 1
        longPress.minimumPressDuration = 0.5
        self.view.addGestureRecognizer(longPress)
    }
    
    func handleLeftSwipeGestureRecognizer(sender: UISwipeGestureRecognizer)
    {
        let transition: CATransition = CATransition()
        transition.startProgress = 0.0
        transition.endProgress = 1.0
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromRight
        transition.duration = 1.0
        
        self.firstView!.layer.addAnimation(transition, forKey: "transition")
        self.secondView!.layer.addAnimation(transition, forKey: "transition")
        
        self.firstView!.hidden = true
        self.secondView!.hidden = false
        
    }
    
    func handleRightSwipeGestureRecognizer(sender: UISwipeGestureRecognizer)
    {
        let transition: CATransition = CATransition()
        transition.startProgress = 0.0
        transition.endProgress = 1.0
        transition.type = kCATransitionPush
        transition.subtype = kCATransitionFromLeft
        transition.duration = 1.0
        
        self.secondView!.layer.addAnimation(transition, forKey: "transition")
        self.firstView!.layer.addAnimation(transition, forKey: "transition")
        
        self.firstView!.hidden = false
        self.secondView!.hidden = true
    }
    
    func handleLongPressGestureRecognizer(sender: UILongPressGestureRecognizer)
    {
        if(sender.state == UIGestureRecognizerState.Began)
        {
            let alertView: UIAlertView = UIAlertView(title: "Long Press Gesture",
                message: "Removed Current View",
                delegate: nil,
                cancelButtonTitle: "OK")
            alertView.show()
            
            if(self.firstView!.hidden && self.secondView != nil)
            {
                self.secondView!.removeFromSuperview()
                self.firstView!.hidden = false
            }
            if(self.secondView!.hidden && self.firstView != nil)
            {
                self.firstView!.removeFromSuperview()
                self.secondView!.hidden = false
            }
        }
    }
    
    func titleLable() -> UILabel
    {
        let label = UILabel(frame: CGRectMake(0, 0, 300, 50))
        label.backgroundColor = UIColor.clearColor()
        label.textColor = UIColor.whiteColor()
        label.font = UIFont.systemFontOfSize(20)
        return label
    }

}

