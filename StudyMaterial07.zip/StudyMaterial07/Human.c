#include <stdio.h>

typedef struct human_type { 
	int __id;
	char __name[100];
	void (*dance)(struct human_type this);
	int (*getId)(struct human_type this);
	char (*getName)(struct human_type this);	
} Human ;

void doDance(Human this) {
	printf("\n\t%s Dance Buddy Dance!!!", this.__name);
}

int getID(Human this) { return this.__id; }
char * getName(Human this) { return this.__name; }

int main() {
	// struct human_type gabbar = { 420, "Gabbar Singh" };
	Human gabbar = { 420, "Gabbar Singh", doDance, getID, getName };
	// printf("\n\tID  : %d", gabbar.id );
	// printf("\n\tName: %s", gabbar.name );
	printf("\n\tID  : %d", gabbar.getId(gabbar) );
	printf("\n\tName: %s", gabbar.getName(gabbar) );

	gabbar.dance(gabbar);

	// doSomething(); 	//Function Call
	// doDance(); 		//Function Call
}

