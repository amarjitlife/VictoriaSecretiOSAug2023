// Define The Human
class Human {
	// Member Variables
	int id = 0;
	String name = "Unknown";
	// Constructor	
	Human(int id, String name) {
		this.id = id;
		this.name = name;
	}
	// Member Function
	public void dance() { 
		System.out.println( this.name );
		System.out.println("\tDance Buddy Dance!!!");
	}

	int getID() 	 { return this.id; }
	String getName() { return this.name; }
}

class HumanDemo {
	public static void main( String [] args ) {
		// Creating Object/Instance of Human Class
		Human gabbar = new Human( 420, "Gabbar Singh" );
		// System.out.println( "\tName: " + gabbar.name );
		// System.out.println( "\tID  : " + gabbar.id );
		System.out.println( "\tID    : " + gabbar.getID() );
		System.out.println( "\tName  : " + gabbar.getName() );
		gabbar.dance();
	
		gabbar = null;
		// gabbar.dance();
// Exception in thread "main" java.lang.NullPointerException
// 	at HumanDemo.main(Experiments.java:32)

		if ( gabbar != null ) System.out.println( "\tID    : " + gabbar.getID() );
		if ( gabbar != null ) System.out.println( "\tName  : " + gabbar.getName() );
		if ( gabbar != null ) gabbar.dance();

	}
}

