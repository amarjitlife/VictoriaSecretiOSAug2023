// Compile Swift Code
// 		swiftc 02SwiftBasicOperations.swift -o operations
// Run Swift Code
//		./operations

// Assignment operator
let b = 10
var a = 5
a = b

// Tuple Unpacking/Decluttering
let (x, y) = (1, 2)

var xx: Int = 10
var yy: Int = 20

// Following Is Valid in C/C++/Objective-C
//		Assignment Statement Can't Be Used In Swift if Expression 
// if xx = yy {
    
// }

// Arithmetic Operators
_ = 1 + 2
_ = 5 - 3
_ = 2 * 3
_ = 10.0 / 2.5
// Swift Arithmetic operators can't overflow

// String Concatination
let greeting = "hello, " + "world"

// Unicode Character : Written with Double Quotes
let dog: Character = "🐶"
let cow: Character = "🐮" 
print( dog, cow )

// error: binary operator '+' cannot be applied to two 'Character' operands
// let dogcow = dog + cow
// print( dogcow )

// String Type
let dogcowAgain = "🐶" + "🐮"
print( dogcowAgain )

var result: Int
// Remainder Operator
result = 9 % 4
print( result )
// a = (b × some multiplier) + remainder
result = -9 % 4
print( result )

// a % b and a % -b
result = 9 % -4
print( result )

result = -9 % -4
print( result )

var aa = 0
// aa++
// ++aa 
aa = aa + 1

// Unary Minus Operator
let three = 3
let minusThree = -three
let plusThree = -minusThree

// Unary Plus Operator
// Doesn't do anything
let minusSix = -6
let alsoMinusSix = +minusSix

// Compound Assignment Operators
var aaa = 1
aaa += 2

// Comparison Operators
1 == 1
2 != 1
2 > 1
1 < 2
1 >= 1
2 <= 1

let name = "world"

// In Swift
// You Can Compare Strings With Equality Operator

// Can YOU Compare Strings With Comparison Operator?
if name == "world" {
    print("hello, world")
} else {
    print("I'm sorry \(name), but I don't recognize you")
}

// In Swift
// You Can Compare Tuples With Comparison Operators
var resultAgain: Bool
resultAgain = (1, "zebra") < (2, "apple")   // true because 1 is less than 2; "zebra" and "apple" are not compared
print( resultAgain )

(3, "apple") < (3, "bird")    // true because 3 is equal to 3, and "apple" is less than "bird"
(4, "dog") == (4, "dog")      // true because 4 is equal to 4, and "dog" is equal to "dog"

("blue", -1) < ("purple", 1)        // OK, evaluates to true

//("blue", false) < ("purple", true)  // Error because < can't compare Boolean values

// Ternary Conditional Operator
// let contentHeight = 40
// let hasHeader = true
// let rowHeight = contentHeight + ( hasHeader ? 50 : 20 )
// print( rowHeight )

let contentHeight = 40
let hasHeader = false
let rowHeight = contentHeight + ( hasHeader ? 50 : 20 )
print( rowHeight )

var choiceValue = ( hasHeader ? 50 : (contentHeight == 40) ? 10 : 100  )
print("Choice Value Using Ternary Operator: ", choiceValue)

if hasHeader {
    choiceValue = 50
} else if ( contentHeight == 40 ) {
    choiceValue = 10
} else {
    choiceValue = 100
}
print("Choice Value Using if-else Construct: ", choiceValue)

if hasHeader {
    choiceValue = 50
} else {
    choiceValue = (contentHeight == 40) ? 10 : 100
}
print("Choice Value Using if-else+Ternary: ", choiceValue)

let rowHeightAgain = contentHeight + choiceValue
print(rowHeightAgain)

// Range Operators
// The Closed Range Operator 
// i.e. Closed Interval [1, 5]
for index in 1...5 {
    print("\(index) times 5 is \(index * 5)")
}

// i.e. Closed Interval [1, 5)
for index in 1..<5 {
    print("\(index) times 5 is \(index * 5)")
}

// The Half-Closed range operator
let names0 = ["Anna", "Alex", "Brian", "Jack"]
let count = names0.count
for i in 0..<count {
    print("Person \(i + 1) is called \(names0[i])")
}

let names = [ "Ding", "Dong", "King", "Kong", "Ting", "Tong" ]
let namesCount = names.count
print(names)

print()
for i in 0..<namesCount {
    print("Person at \(i) is: \(names[i])")
}

print()
for name in names {
    print("Person Name: \(name)")
}

print()
for name in names[2...] {
    print("Person Name: \(name)")
}

print()
for name in names[...2] {
    print("Person Name: \(name)")
}

print()
for name in names[..<2] {
    print("Person Name: \(name)")
}

print()
for name in names[2...5] {
    print("Person Name: \(name)")
}

let range1 = 1...10
print(range1)
for value in range1 {
    print(value)
}

let range2 = ...10
print(range2)
// Runtime Error: Not provided starting value
// for value in range2 {
//     print(value)
// }

let range3 = 1...
print(range3)
// Infinite Loop
// for value in range3 {
//     print(value)
//}

for value in range3 {
    if value == 100 { break }
    print(value)
}

// Logical Operators
let allowedEntry = false
if !allowedEntry {
    print("ACCESS DENIED")
}

let enteredDoorCode = true
let passedRetinaScan = false
if enteredDoorCode && passedRetinaScan {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

let hasDoorKey = false
let knowsOverridePassword = true
if hasDoorKey || knowsOverridePassword {
    print("Welcome")
} else {
    print("ACCESS DENIED")
}

if enteredDoorCode && passedRetinaScan || hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

if (enteredDoorCode && passedRetinaScan) || hasDoorKey || knowsOverridePassword {
    print("Welcome!")
} else {
    print("ACCESS DENIED")
}

//____________________________________________________________
//____________________________________________________________
//____________________________________________________________
//____________________________________________________________


// https://codebunk.com/b/6011100615319/
// https://codebunk.com/b/6011100615319/
// https://codebunk.com/b/6011100615319/


