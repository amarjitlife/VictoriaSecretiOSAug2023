// Compile Swift Code
//      swiftc 09SwiftStructuresAndClasses.swift -o structures
// Run Swift Code
//      ./structures

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

struct SomeStruct {

}

class SomeClass {

}

struct Resolution {
	var width 	= 0  // Initialised With Default Values
	var height	= 0  // Default Values
}

class VideoMode {
	var resolution 	= Resolution()
	var interlaced 	= false
	var frameRate 	= 0.0
	var name: String?
}

let someResolution = Resolution()
let someVideoMode  = VideoMode()

print("someResolution Data")
print( "\tWidth : \(someResolution.width)" ) 
print( "\tHeight: \(someResolution.height)")

print("someVideo Data")
print( "\tWidth : \(someVideoMode.resolution.width)" ) 
print(" \tHeight: \(someVideoMode.resolution.height)" ) 
print( "\tInterlaced : \(someVideoMode.interlaced)" ) 
print(" \tFramerate : \(someVideoMode.frameRate)" ) 
print(" \tName : \( someVideoMode.name ?? "UNKNOWN" )" ) 

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Value Types
//		Int, Char, Float, Double, String, Array, Structure and Enums Are Value Types

let vga = Resolution(width: 640, height: 480)
print( vga )

print("\n\nAssingment Of Structure : Value Type")
var hd = Resolution(width: 1920, height: 1080)
// Value Assignment
let cinema = hd

print( hd )
print( cinema )

hd.width = 2048

print( hd )
print( cinema )

print("\n\nAssingment Of Enums : Value Type ")

enum CompassPoint {
    case Noth, South, East, West
}

var currentDirection = CompassPoint.West

// Value Assignment
let rememberedDirection = currentDirection
print( rememberedDirection )
print( currentDirection )

currentDirection = .East

print( rememberedDirection )
print( currentDirection )

if rememberedDirection == .West {
    print("The remembered direction is still .West")
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// Reference Types In Swift
//		Closures and Classes Are Reference Types In Swift

let tenEighty = VideoMode()
tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.name = "1080i"
tenEighty.frameRate = 60.0

// Reference Assignment
let alsoTenEighty = tenEighty

print("tenEighty Data")
print( "\tWidth : \(tenEighty.resolution.width)" ) 
print(" \tHeight: \(tenEighty.resolution.height)" ) 
print( "\tInterlaced : \(tenEighty.interlaced)" ) 
print(" \tName : \( tenEighty.name ?? "UNKNOWN" )" ) 
print(" \tFramerate : \(tenEighty.frameRate)" ) 

print("alsoTenEighty Data")
print( "\tWidth : \(alsoTenEighty.resolution.width)" ) 
print(" \tHeight: \(alsoTenEighty.resolution.height)" ) 
print( "\tInterlaced : \(alsoTenEighty.interlaced)" ) 
print(" \tFramerate : \(alsoTenEighty.frameRate)" ) 
print(" \tName : \( alsoTenEighty.name ?? "UNKNOWN" )" ) 

alsoTenEighty.frameRate = 120.0

print("tenEighty Data")
print( "\tWidth : \(tenEighty.resolution.width)" ) 
print(" \tHeight: \(tenEighty.resolution.height)" ) 
print( "\tInterlaced : \(tenEighty.interlaced)" ) 
print(" \tName : \( tenEighty.name ?? "UNKNOWN" )" ) 
print(" \tFramerate : \(tenEighty.frameRate)" ) 

print("alsoTenEighty Data")
print( "\tWidth : \(alsoTenEighty.resolution.width)" ) 
print(" \tHeight: \(alsoTenEighty.resolution.height)" ) 
print( "\tInterlaced : \(alsoTenEighty.interlaced)" ) 
print(" \tFramerate : \(alsoTenEighty.frameRate)" ) 
print(" \tName : \( alsoTenEighty.name ?? "UNKNOWN" )" ) 


// Identity Operators
if tenEighty === alsoTenEighty {
    print("tenEighty and alsoTenEighty reference to the same VideoMode instance.")
}


//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________
//__________________________________________________________

