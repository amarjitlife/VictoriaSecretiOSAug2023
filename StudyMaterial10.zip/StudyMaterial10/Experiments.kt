// Compiling Kotlin Program
//		kotlinc Experiments.kt -include-runtime -d experiments.jar

// Running Kotlin Code
//		java -jar experiments.jar

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

// func makeIncrementor( amount: Int ) -> () -> Int {
fun makeIncrementor( amount: Int ) : () -> Int {
    var runningTotal = 0

    // func incrementor() -> Int {
	fun incrementor() : Int {	
        runningTotal += amount
        return runningTotal
    }
    
    return ::incrementor
}

fun playWithMakeIncrementer() {
	val incrementorByTen: () -> Int = makeIncrementor( amount = 10 )
	println( incrementorByTen() )
	println( incrementorByTen() )
	println( incrementorByTen() )

	val incrementorBySeven: () -> Int = makeIncrementor( amount = 7 )
	println( incrementorBySeven() )
	println( incrementorBySeven() )
}

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

//__________________________________________________________
// EXPERIMENT FOLLOWING CODE! MOMENT DONE RAISE YOUR FLAG!!!

fun main() {
	println("\nFunction : playWithMakeIncrementer")
	playWithMakeIncrementer()

	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
	// println("\nFunction : ")
}

//__________________________________________________________
//__________________________________________________________
